// =============================================
// File: src/components/forms/ExploracionFisicaForm.tsx
// =============================================
import React from "react";

export type ExploracionFisicaData = {
  hallazgosGenerales?: string;
  resumenSistemas?: string;
};

type PropsE = { value: ExploracionFisicaData | null; onChange: (v: ExploracionFisicaData | null) => void };
export default function ExploracionFisicaForm({ value, onChange }: PropsE) {
  const v = value ?? {};
  const set = (patch: Partial<ExploracionFisicaData>) => onChange({ ...v, ...patch });
  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm text-zinc-400 mb-1">Hallazgos generales</label>
        <textarea className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100" rows={3}
          value={v.hallazgosGenerales ?? ""} onChange={(e) => set({ hallazgosGenerales: e.target.value })} />
      </div>
      <div>
        <label className="block text-sm text-zinc-400 mb-1">Resumen por sistemas</label>
        <textarea className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100" rows={3}
          value={v.resumenSistemas ?? ""} onChange={(e) => set({ resumenSistemas: e.target.value })} />
      </div>
    </div>
  );
}
