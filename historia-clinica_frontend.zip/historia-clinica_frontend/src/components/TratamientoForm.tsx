// =============================================
// File: src/components/forms/TratamientoForm.tsx
// =============================================
import React from "react";

export type TratamientoData = {
  indicacionesGenerales?: string;
  prescripcionesResumen?: string; // texto libre; luego podemos migrar a tabla
};

type PropsT = { value: TratamientoData | null; onChange: (v: TratamientoData | null) => void };
export default function TratamientoForm({ value, onChange }: PropsT) {
  const v = value ?? {};
  const set = (patch: Partial<TratamientoData>) => onChange({ ...v, ...patch });
  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm text-zinc-400 mb-1">Indicaciones</label>
        <textarea className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100" rows={3}
          value={v.indicacionesGenerales ?? ""} onChange={(e) => set({ indicacionesGenerales: e.target.value })} />
      </div>
      <div>
        <label className="block text-sm text-zinc-400 mb-1">Prescripciones</label>
        <textarea className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100" rows={3}
          value={v.prescripcionesResumen ?? ""} onChange={(e) => set({ prescripcionesResumen: e.target.value })} />
      </div>
    </div>
  );
}
