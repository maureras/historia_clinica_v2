// src/components/forms/LaboratorioForm.tsx
import React from "react";

// ✅ EXPORTAR el tipo
export type LaboratorioData = {
  ordenesResumen?: string;
  resultadosResumen?: string;
};

type PropsL = {
  value: LaboratorioData | null;
  onChange: (v: LaboratorioData | null) => void;
};

const LaboratorioForm: React.FC<PropsL> = ({ value, onChange }) => {
  const v = value ?? {};
  const set = (patch: Partial<LaboratorioData>) => onChange({ ...v, ...patch });

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm text-zinc-400 mb-1">Exámenes solicitados</label>
        <textarea
          className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
          rows={3}
          value={v.ordenesResumen ?? ""}
          onChange={(e) => set({ ordenesResumen: e.target.value })}
        />
      </div>
      <div>
        <label className="block text-sm text-zinc-400 mb-1">Resultados clave</label>
        <textarea
          className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
          rows={3}
          value={v.resultadosResumen ?? ""}
          onChange={(e) => set({ resultadosResumen: e.target.value })}
        />
      </div>
    </div>
  );
};

export default LaboratorioForm;