// =============================================
// File: src/components/forms/DiagnosticoForm.tsx
// =============================================
import React from "react";

export type DiagnosticoData = {
  codigoCIE10?: string;
  descripcion?: string;
  impresionClinica?: string;
};

type PropsD = { value: DiagnosticoData | null; onChange: (v: DiagnosticoData | null) => void };
export default function DiagnosticoForm({ value, onChange }: PropsD) {
  const v = value ?? {};
  const set = (patch: Partial<DiagnosticoData>) => onChange({ ...v, ...patch });
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm text-zinc-400 mb-1">CIE-10</label>
          <input className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
            value={v.codigoCIE10 ?? ""} onChange={(e) => set({ codigoCIE10: e.target.value })} placeholder="Ej. J10.1" />
        </div>
        <div>
          <label className="block text-sm text-zinc-400 mb-1">Descripción</label>
          <input className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
            value={v.descripcion ?? ""} onChange={(e) => set({ descripcion: e.target.value })} />
        </div>
      </div>
      <div>
        <label className="block text-sm text-zinc-400 mb-1">Impresión clínica</label>
        <textarea className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100" rows={3}
          value={v.impresionClinica ?? ""} onChange={(e) => set({ impresionClinica: e.target.value })} />
      </div>
    </div>
  );
}