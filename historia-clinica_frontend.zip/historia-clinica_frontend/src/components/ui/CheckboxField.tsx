import React from "react";

export interface CheckboxFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
}

export const CheckboxField: React.FC<CheckboxFieldProps> = ({ label, className = "", ...props }) => {
  return (
    <label className="flex items-center gap-2 text-sm text-gray-700">
      <input
        type="checkbox"
        {...props}
        className={`h-4 w-4 text-blue-600 border-gray-300 rounded ${className}`}
      />
      {label}
    </label>
  );
};