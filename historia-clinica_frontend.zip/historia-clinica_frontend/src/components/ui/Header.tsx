import React from "react";

export default function Header() {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="mx-auto max-w-[var(--container)] h-14 px-4 lg:px-6 flex items-center justify-between">
        <h1 className="text-sm font-semibold tracking-wide text-slate-900">Historia Clínica</h1>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">v1</span>
        </div>
      </div>
    </header>
  );
}