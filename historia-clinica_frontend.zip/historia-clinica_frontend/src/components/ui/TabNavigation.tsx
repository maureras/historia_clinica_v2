import React from "react";

export type Tab = { id: string; label: string; icon: React.ComponentType<{ className?: string }> };

export const TabNavigation: React.FC<{
  tabs: Tab[];
  activeTab: string;
  onTabChange: (tab: string) => void;
}> = ({ tabs, activeTab, onTabChange }) => (
  <div className="p-4 border-b border-slate-200">
    <div className="flex flex-wrap gap-2">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg transition-all duration-200 ${
            activeTab === tab.id
              ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg"
              : "text-slate-600 hover:text-blue-600 hover:bg-blue-50 border border-slate-200"
          }`}
        >
          <tab.icon className="w-4 h-4" />
          {tab.label}
        </button>
      ))}
    </div>
  </div>
);