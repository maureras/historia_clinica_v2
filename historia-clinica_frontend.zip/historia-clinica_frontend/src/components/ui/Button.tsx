// src/components/ui/Button.tsx
import React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { twMerge } from "tailwind-merge";
import { Save } from "lucide-react"; // Manteniendo tu ícono de carga

// --- 1. Definimos las variantes y sus estilos con CVA ---
const buttonVariants = cva(
  // Estilos base que todos los botones comparten
  "flex items-center justify-center gap-2 px-6 py-3 rounded-lg font-bold shadow-lg disabled:opacity-60 disabled:cursor-not-allowed transition-all duration-200",
  {
    variants: {
      variant: {
        // Tus variantes de color existentes
        primary: "bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white",
        secondary: "bg-gray-500 hover:bg-gray-600 text-white",
        danger: "bg-red-600 hover:bg-red-700 text-white",
        // Aquí puedes añadir más variantes en el futuro si quieres
      },
      // También podemos añadir variantes de tamaño como extra
      size: {
        default: 'h-12 text-base', // Ajustado a tu py-3
        sm: 'h-9 px-3 text-sm',
      }
    },
    defaultVariants: {
      variant: "primary",
      size: "default",
    },
  }
);

// --- 2. Creamos los props del componente a partir de las variantes ---
// Mantenemos tus props originales y añadimos los de las variantes
export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  loading?: boolean;
  icon?: React.ComponentType<{ className?: string }>;
}


// --- 3. Creamos el componente del botón ---
export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({
    className,
    variant,
    size, // <-- Nuevo prop de tamaño
    children,
    onClick,
    loading = false,
    type = "button",
    disabled = false,
    icon: Icon,
    ...props // Pasamos el resto de los props al botón
  }, ref) => {
    return (
      <button
        type={type}
        onClick={onClick}
        disabled={disabled || loading}
        // --- LA MAGIA OCURRE AQUÍ ---
        // twMerge fusiona inteligentemente las clases de la variante
        // con las que pasas en `className`. Las de `className` siempre ganan.
        className={twMerge(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      >
        {/* Mantenemos tu lógica de carga y de íconos intacta */}
        {loading ? <Save className="w-5 h-5 animate-spin" /> : Icon ? <Icon className="w-5 h-5" /> : null}
        {loading ? "Procesando..." : children}
      </button>
    );
  }
);
Button.displayName = "Button";