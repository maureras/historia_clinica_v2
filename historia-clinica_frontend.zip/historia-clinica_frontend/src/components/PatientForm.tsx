// =============================================
// File: src/components/PatientForm.tsx
// =============================================
import React from "react";

export type PatientData = {
  nombres: string;
  apellidos: string;
  fechaNacimiento: string; // ISO (YYYY-MM-DD)
  sexo: "Masculino" | "Femenino" | "Otro" | "";
  email?: string;
  celular?: string;
  sinCelular?: boolean;
  tipoIdentificacion: "Cédula" | "Pasaporte" | "Otro" | "";
  numeroIdentificacion?: string;
  telefono?: string;
  aceptaWhatsapp?: boolean;
  enviarCorreo?: boolean;
  direccion?: string;
};

type Props = {
  value: PatientData | null;
  onChange: (val: PatientData | null) => void;
};

const empty: PatientData = {
  nombres: "",
  apellidos: "",
  fechaNacimiento: "",
  sexo: "",
  email: "",
  celular: "",
  sinCelular: false,
  tipoIdentificacion: "",
  numeroIdentificacion: "",
  telefono: "",
  aceptaWhatsapp: false,
  enviarCorreo: false,
  direccion: "",
};

export default function PatientForm({ value, onChange }: Props) {
  const v = value ?? empty;
  const set = (patch: Partial<PatientData>) => onChange({ ...v, ...patch });

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm text-zinc-400 mb-1">Nombres</label>
          <input
            className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
            value={v.nombres}
            onChange={(e) => set({ nombres: e.target.value })}
            placeholder="Ej. Juan Carlos"
          />
        </div>
        <div>
          <label className="block text-sm text-zinc-400 mb-1">Apellidos</label>
          <input
            className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
            value={v.apellidos}
            onChange={(e) => set({ apellidos: e.target.value })}
            placeholder="Ej. Paredes Ramírez"
          />
        </div>
        <div>
          <label className="block text-sm text-zinc-400 mb-1">Fecha de nacimiento</label>
          <input
            type="date"
            className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
            value={v.fechaNacimiento?.slice(0, 10) || ""}
            onChange={(e) => set({ fechaNacimiento: e.target.value })}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div>
          <label className="block text-sm text-zinc-400 mb-1">Tipo de identificación</label>
          <select
            className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
            value={v.tipoIdentificacion}
            onChange={(e) => set({ tipoIdentificacion: e.target.value as PatientData["tipoIdentificacion"] })}
          >
            <option value="">- Seleccionar -</option>
            <option value="Cédula">Cédula</option>
            <option value="Pasaporte">Pasaporte</option>
            <option value="Otro">Otro</option>
          </select>
        </div>
        <div>
          <label className="block text-sm text-zinc-400 mb-1">No. identificación</label>
          <input
            className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
            value={v.numeroIdentificacion ?? ""}
            onChange={(e) => set({ numeroIdentificacion: e.target.value })}
            placeholder="1715956833"
          />
        </div>
        <div>
          <label className="block text-sm text-zinc-400 mb-1">Sexo</label>
          <select
            className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
            value={v.sexo}
            onChange={(e) => set({ sexo: e.target.value as PatientData["sexo"] })}
          >
            <option value="">- Seleccionar -</option>
            <option value="Masculino">Masculino</option>
            <option value="Femenino">Femenino</option>
            <option value="Otro">Otro</option>
          </select>
        </div>
        <div className="flex items-end gap-2">
          <label className="flex items-center gap-2 text-sm text-zinc-300">
            <input
              type="checkbox"
              checked={!!v.aceptaWhatsapp}
              onChange={(e) => set({ aceptaWhatsapp: e.target.checked })}
            />
            Acepta WhatsApp
          </label>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm text-zinc-400 mb-1">Celular</label>
          <input
            className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
            value={v.celular ?? ""}
            onChange={(e) => set({ celular: e.target.value })}
            placeholder="09xxxxx"
          />
          <label className="mt-2 flex items-center gap-2 text-sm text-zinc-300">
            <input
              type="checkbox"
              checked={!!v.sinCelular}
              onChange={(e) => set({ sinCelular: e.target.checked })}
            />
            Sin celular
          </label>
        </div>
        <div>
          <label className="block text-sm text-zinc-400 mb-1">Teléfono</label>
          <input
            className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
            value={v.telefono ?? ""}
            onChange={(e) => set({ telefono: e.target.value })}
            placeholder="02xxxxxx"
          />
        </div>
        <div>
          <label className="block text-sm text-zinc-400 mb-1">Email</label>
          <input
            type="email"
            className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
            value={v.email ?? ""}
            onChange={(e) => set({ email: e.target.value })}
            placeholder="correo@dominio.com"
          />
          <label className="mt-2 flex items-center gap-2 text-sm text-zinc-300">
            <input
              type="checkbox"
              checked={!!v.enviarCorreo}
              onChange={(e) => set({ enviarCorreo: e.target.checked })}
            />
            Enviar correos de resumen
          </label>
        </div>
      </div>

      <div>
        <label className="block text-sm text-zinc-400 mb-1">Dirección</label>
        <input
          className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100"
          value={v.direccion ?? ""}
          onChange={(e) => set({ direccion: e.target.value })}
          placeholder="Calle y número, referencia"
        />
      </div>
    </div>
  );
}
