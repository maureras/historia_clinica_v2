import React, { useState } from "react";
import { User, ClipboardList, AlertTriangle, Activity, Stethoscope, Brain, Pill, TestTube, FileText, Save } from "lucide-react";
import { ApiService } from '../api/ApiService';
import { PageContainer, MotionCard, CardHeader, TabNavigation, Button, Alert } from './ui';

// Formularios modulares
import PatientForm from './PatientForm';
import AntecedentesForm from "./forms/AntecedentesForm";
import PadecimientoActualForm from "./forms/PadecimientoActualForm.tsx_bk";
import DiagnosticoForm from './forms/DiagnosticoForm';
import TratamientoForm from './forms/TratamientoForm';
import SignosVitalesForm from './forms/SignosVitalesForm';
import ExploracionFisicaForm from './forms/ExploracionFisicaForm';
import LaboratorioForm from "./forms/LaboratorioForm";

// Tipos de datos
import type { PatientData } from './PatientForm';
import type { AntecedentesData } from "./forms/AntecedentesForm";
import type { PadecimientoActualData } from "./forms/PadecimientoActualForm.tsx_bk";
import type { DiagnosticoData } from './forms/DiagnosticoForm';
import type { TratamientoData } from './forms/TratamientoForm';
import type { SignosVitalesData } from './forms/SignosVitalesForm';
import type { ExploracionFisicaData } from './forms/ExploracionFisicaForm';

export default function HistoriaClinica() {
  const tabs = [
    { id: "nuevo-paciente",   label: "Datos Paciente",        icon: User },
    { id: "padecimiento",     label: "Padecimiento Actual",   icon: AlertTriangle },
    { id: "vitales",          label: "Signos Vitales",        icon: Activity },
    { id: "antecedentes",     label: "Antecedentes",          icon: ClipboardList },
    { id: "exploracion",      label: "Exploración Física",    icon: Stethoscope },
    { id: "diagnostico",      label: "Diagnóstico",           icon: Brain },
    { id: "tratamiento",      label: "Tratamiento",           icon: Pill },
    { id: "laboratorio",      label: "Laboratorio",           icon: TestTube }
  ];

  const [activeTab, setActiveTab] = useState("nuevo-paciente");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [qrData, setQrData] = useState<string | null>(null);
  const [currentPatientId, setCurrentPatientId] = useState<number | null>(null);

  const [paciente, setPaciente] = useState<PatientData>({
    nombres: '', apellidos: '', fechaNacimiento: '', sexo: 'Masculino', email: '',
    celular: '', sinCelular: false, tipoIdentificacion: 'Cédula', numeroIdentificacion: '',
    telefono: '', aceptaWhatsapp: true, enviarCorreo: true, direccion: '', pais: '',
    estado: '', ciudad: '', codigoPostal: '', numeroExterior: '', numeroInterior: '',
    notas: '', foto: '', edad: '', ocupacion: '', estadoCivil: '', contactoEmergencia: '',
  });

  const [antecedentes, setAntecedentes] = useState<AntecedentesData>({ 
    personalesPatologicos: "", personalesNoPatologicos: "", familiares: "", 
    ginecobstetricos: "", quirurgicos: "", alergias: "", medicamentos: "" 
  });

  const [padecimientoActual, setPadecimientoActual] = useState<PadecimientoActualData>({
    motivoConsulta: "", inicioSintomas: "", evolucion: "", sintomasAsociados: "", tratamientoPrevio: ""
  });

  const [diagnostico, setDiagnostico] = useState<DiagnosticoData>({
    principal: "", secundarios: "", diferencial: "", cie10: ""
  });

  const [tratamiento, setTratamiento] = useState<TratamientoData>({
    medicamentos: "", indicaciones: "", recomendaciones: "", proximaCita: ""
  });

  const [signosVitales, setSignosVitales] = useState<SignosVitalesData>({ 
    temperatura: "", presionSistolica: "", presionDiastolica: "", frecuenciaCardiaca: "", 
    frecuenciaRespiratoria: "", saturacionOxigeno: "", peso: "", talla: "", imc: "", 
    tipoSangre: "" 
  });

  const [exploracionFisica, setExploracionFisica] = useState<ExploracionFisicaData>({
    exploracionGeneral: { aspectoGeneral: "", estadoConciencia: "", orientacion: "", hidratacion: "", coloracion: "", constitucion: "", actitud: "", facies: "", marcha: "" },
    exploracionSistemas: { cabezaCuello: "", cardiopulmonar: "", abdomen: "", extremidades: "", neurologico: "", piel: "", ganglios: "", genitourinario: "" },
    hallazgosEspecificos: { hallazgosNormales: [], hallazgosAnormales: [], impresionClinica: "" },
    observacionesGenerales: "", fechaExploracion: new Date().toISOString().split('T')[0], exploradoPor: ""
  });

  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);

  // Handlers
  const handlePatientChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const finalValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setPaciente(prev => ({ ...prev, [name]: finalValue }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setPaciente(prev => ({ ...prev, foto: reader.result as string }));
      reader.readAsDataURL(file);
    }
  };

  const handleAntecedentesChange = (data: AntecedentesData) => setAntecedentes(data);
  const handlePadecimientoActualChange = (data: PadecimientoActualData) => setPadecimientoActual(data);
  const handleDiagnosticoChange = (data: DiagnosticoData) => setDiagnostico(data);
  const handleTratamientoChange = (data: TratamientoData) => setTratamiento(data);
  const handleSignosVitalesChange = (field: keyof SignosVitalesData, value: string) => setSignosVitales(prev => ({ ...prev, [field]: value }));
  const handleExploracionFisicaChange = (data: ExploracionFisicaData) => setExploracionFisica(data);

  // Recibir archivos desde LaboratorioForm
  const handleFileSelect = (files: File[]) => {
    setUploadedFiles(prev => [...prev, ...files]);
  };

  // Mantengo este método por si más adelante quieres subir desde el padre
  const handleUploadFiles = async () => {
    if (uploadedFiles.length === 0) { setError("No hay archivos para subir"); return; }
    if (!currentPatientId) { setError("Debe seleccionar un paciente primero"); return; }

    setIsLoading(true); setError("");
    try {
      const base = import.meta.env.VITE_API_URL || 'http://localhost:3000';

      for (const file of uploadedFiles) {
        const form = new FormData();
        form.append('paciente_id', currentPatientId.toString());
        form.append('incluir_resumen', 'true');
        form.append('guardar_archivo', 'true');
        form.append('file', file);

        // ✅ ENDPOINT CORREGIDO (coincide con tu router labs.js)
        const res = await fetch(`${base}/api/labs/upload`, { method: 'POST', body: form });

        const contentType = res.headers.get('content-type') || '';
        let data;
        if (contentType.includes('application/json')) {
          data = await res.json();
        } else {
          const textResponse = await res.text();
          throw new Error(textResponse || 'Respuesta no válida del servidor');
        }

        if (!res.ok || !data?.success) {
          throw new Error(data?.error || `Error subiendo ${file.name}: ${res.status}`);
        }
      }

      setUploadedFiles([]);
      alert('Archivo(s) procesado(s) exitosamente');
    } catch (err: any) {
      setError(err?.message || 'Error al subir o analizar el archivo');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsLoading(true);
    setError("");
    try {
      if (!currentPatientId && activeTab !== 'nuevo-paciente') {
        throw new Error("Debe crear o seleccionar un paciente primero.");
      }
      switch(activeTab) {
        case "nuevo-paciente": {
          const response = await ApiService.createPatient(paciente);
          if (response.success && response.data?.patient.id) {
            setCurrentPatientId(response.data.patient.id);
            setQrData(`ID del Paciente: ${response.data.patient.id}`);
            alert('¡Paciente creado con éxito!');
          } else { 
            throw new Error(response.error || 'Error al crear paciente.'); 
          }
          break;
        }
        case "antecedentes":
        case "padecimiento":
        case "diagnostico":
        case "tratamiento":
          alert(`${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} guardado (simulación).`);
          break;
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Ocurrió un error");
    } finally {
      setIsLoading(false);
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "nuevo-paciente":
        return <PatientForm patient={paciente} onPatientChange={handlePatientChange} onFileChange={handleFileChange} qrData={qrData} />;
      case "padecimiento":
        return <PadecimientoActualForm data={padecimientoActual} onChange={handlePadecimientoActualChange} readOnly={!currentPatientId} />;
      case "vitales":
        return <SignosVitalesForm data={signosVitales} onChange={handleSignosVitalesChange} onSave={() => {}} isLoading={isLoading} readOnly={!currentPatientId} />;
      case "antecedentes":
        return <AntecedentesForm data={antecedentes} onChange={handleAntecedentesChange} readOnly={!currentPatientId} />;
      case "exploracion":
        return <ExploracionFisicaForm data={exploracionFisica} onChange={handleExploracionFisicaChange} onSave={() => {}} isLoading={isLoading} readOnly={!currentPatientId} />;
      case "diagnostico":
        return <DiagnosticoForm data={diagnostico} onChange={handleDiagnosticoChange} readOnly={!currentPatientId} />;
      case "tratamiento":
        return <TratamientoForm data={tratamiento} onChange={handleTratamientoChange} readOnly={!currentPatientId} />;
      case "laboratorio":
        // ✅ NO PASAMOS onUpload: el hijo maneja su propio flujo y pinta los resultados
        return (
          <LaboratorioForm
            uploadedFiles={uploadedFiles}
            onFilesChange={handleFileSelect}
            isLoading={isLoading}
            readOnly={false}
            //readOnly={!currentPatientId}
          />
        );
      default:
        return <div className="p-6 text-center">Sección en Desarrollo</div>;
    }
  };

  return (
    <PageContainer>
      <MotionCard className="mb-6">
        <CardHeader title="Historia Clínica" icon={FileText} />
        <TabNavigation tabs={tabs} activeTab={activeTab} onTabChange={setActiveTab} />
      </MotionCard>
      <MotionCard>
        {error && <Alert type="error" className="m-6">{error}</Alert>}
        <div className="min-h-[600px]">{renderTabContent()}</div>
        {(activeTab === "nuevo-paciente" || activeTab === "antecedentes" || activeTab === "padecimiento" || activeTab === "diagnostico" || activeTab === "tratamiento") && (
          <div className="flex justify-end p-6 pt-4 border-t border-slate-200 bg-slate-50 rounded-b-xl">
            <Button onClick={handleSave} loading={isLoading} className="px-8 py-4 text-lg" icon={Save}>
              Guardar Cambios
            </Button>
          </div>
        )}
      </MotionCard>
    </PageContainer>
  );
}