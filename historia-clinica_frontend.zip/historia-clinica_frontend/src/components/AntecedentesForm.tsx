// =============================================
// File: src/components/AntecedentesForm.tsx
// =============================================
import React from "react";

export type AntecedentesData = {
  patologicos?: string;
  familiares?: string;
  alergias?: string;
  medicamentosHabituales?: string;
};

type PropsA = { value: AntecedentesData | null; onChange: (v: AntecedentesData | null) => void };
export default function AntecedentesForm({ value, onChange }: PropsA) {
  const v = value ?? {};
  const set = (patch: Partial<AntecedentesData>) => onChange({ ...v, ...patch });
  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm text-zinc-400 mb-1">Patológicos</label>
        <textarea className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100" rows={3}
          value={v.patologicos ?? ""} onChange={(e) => set({ patologicos: e.target.value })} />
      </div>
      <div>
        <label className="block text-sm text-zinc-400 mb-1">Familiares</label>
        <textarea className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100" rows={3}
          value={v.familiares ?? ""} onChange={(e) => set({ familiares: e.target.value })} />
      </div>
      <div>
        <label className="block text-sm text-zinc-400 mb-1">Alergias</label>
        <textarea className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100" rows={2}
          value={v.alergias ?? ""} onChange={(e) => set({ alergias: e.target.value })} />
      </div>
      <div>
        <label className="block text-sm text-zinc-400 mb-1">Medicamentos habituales</label>
        <textarea className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-zinc-100" rows={2}
          value={v.medicamentosHabituales ?? ""} onChange={(e) => set({ medicamentosHabituales: e.target.value })} />
      </div>
    </div>
  );
}
