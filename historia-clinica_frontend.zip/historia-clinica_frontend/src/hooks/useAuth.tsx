// src/hooks/useAuth.tsx
import React, { useState, useEffect, useContext, createContext, ReactNode } from 'react';
import { authService, User } from '../services/authService';

const normalizeUser = (u: any): User => {
  if (!u) return u;
  return {
    ...u,
    nombres: u?.nombres ?? u?.nombre ?? '',
    apellidos: u?.apellidos ?? u?.apellido ?? '',
  };
};

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string, remember?: boolean) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Provider del contexto de autenticación
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const result = await authService.verifyToken();
      if (result.valid && result.user) {
        setUser(normalizeUser(result.user));
      } else {
        setUser(null);
      }
    } catch (error) {
      console.error('Error verificando autenticación:', error);
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  const login = async (email: string, password: string, remember = false) => {
    try {
      const result = await authService.login({ email, password, remember });
      if (result.ok && result.user) {
        setUser(normalizeUser(result.user));
        return { success: true };
      } else {
        return {
          success: false,
          error: result.error || 'Error en el login',
        };
      }
    } catch (error) {
      return {
        success: false,
        error: 'Error de conexión',
      };
    }
  };

  const logout = async () => {
    try {
      await authService.logout();
    } finally {
      setUser(null);
    }
  };

  const value = {
    user,
    loading,
    login,
    logout,
    isAuthenticated: !!user,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// Hook para usar el contexto de autenticación
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth debe usarse dentro de AuthProvider');
  }
  return context;
}
