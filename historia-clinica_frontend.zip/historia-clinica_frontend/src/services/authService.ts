// src/services/authService.ts

export interface User {
  id: number;
  email: string;
  nombres: string;
  apellidos: string;
  rol: 'ADMIN' | 'MEDICO' | 'ENFERMERA' | 'ADMINISTRATIVO';
  especialidad?: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
  remember?: boolean;
}

export interface AuthResponse {
  ok: boolean;
  user?: User;
  token?: string;
  message?: string;
  error?: string;
}

class AuthService {
  // ✅ Usa VITE_API_URL
  private baseURL = `${import.meta.env.VITE_API_URL || 'http://localhost:4000'}/api/auth`;
  // ✅ Clave única y consistente para el token
  private tokenKey = 'clinica_token';

  // ===== Token helpers =====
  getToken(): string | null {
    try {
      const raw = localStorage.getItem(this.tokenKey);
      return raw ? raw.replace(/^"+|"+$/g, '').trim() : null; // limpia comillas/espacios accidentales
    } catch {
      return null;
    }
  }

  private setToken(token: string): void {
    try {
      localStorage.setItem(this.tokenKey, token);
    } catch (error) {
      console.error('Error guardando token:', error);
    }
  }

  private removeToken(): void {
    try {
      localStorage.removeItem(this.tokenKey);
    } catch (error) {
      console.error('Error removiendo token:', error);
    }
  }

  // 👉 Público, para usar fuera del servicio (GET/DELETE o FormData)
  public authHeaders(extra?: HeadersInit): HeadersInit {
    const token = this.getToken();
    return {
      Accept: 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...(extra || {}),
    };
  }

  // 👉 Público, para POST/PUT/PATCH con JSON
  public authJsonHeaders(extra?: HeadersInit): HeadersInit {
    return this.authHeaders({
      'Content-Type': 'application/json',
      ...(extra || {}),
    });
  }

  // 👉 Público, por si quieres limpiar el token manualmente en un 401
  public clearToken(): void {
    this.removeToken();
  }

  // ===== Auth API =====
  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    try {
      console.log('🔐 Intentando login en:', `${this.baseURL}/login`);
      
      const response = await fetch(`${this.baseURL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(credentials)
      });

      const data = await response.json();
      console.log('📥 Respuesta del login:', { ok: data.ok, hasToken: !!data.token });

      if (data.ok && data.token) {
        this.setToken(data.token);
        console.log('✅ Token guardado exitosamente');
        return {
          ok: true,
          user: data.user,
          token: data.token,
          message: data.message
        };
      } else {
        console.error('❌ Login fallido:', data.message);
        return {
          ok: false,
          error: data.message || 'Error en el login'
        };
      }
    } catch (error) {
      console.error('❌ Error en login:', error);
      return {
        ok: false,
        error: 'Error de conexión con el servidor'
      };
    }
  }

  async logout(): Promise<void> {
    try {
      const token = this.getToken();
      if (token) {
        await fetch(`${this.baseURL}/logout`, {
          method: 'POST',
          headers: this.authHeaders(),
          credentials: 'include'
        });
      }
    } catch (error) {
      console.error('Error en logout:', error);
    } finally {
      this.removeToken();
    }
  }

  async verifyToken(): Promise<{ valid: boolean; user?: User }> {
    try {
      const token = this.getToken();
      if (!token) return { valid: false };

      const response = await fetch(`${this.baseURL}/verify`, {
        headers: this.authHeaders(),
        credentials: 'include'
      });

      const data = await response.json();

      if (data.ok && data.valid) {
        return { valid: true, user: data.user };
      } else {
        this.removeToken();
        return { valid: false };
      }
    } catch (error) {
      console.error('Error verificando token:', error);
      this.removeToken();
      return { valid: false };
    }
  }

  async getMe(): Promise<{ ok: boolean; user?: User; error?: string }> {
    try {
      const response = await fetch(`${this.baseURL}/me`, {
        headers: this.authHeaders(),
        credentials: 'include'
      });

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error obteniendo perfil:', error);
      return { ok: false, error: 'Error de conexión' };
    }
  }

  isAuthenticated(): boolean {
    return !!this.getToken();
  }
}

export const authService = new AuthService();
