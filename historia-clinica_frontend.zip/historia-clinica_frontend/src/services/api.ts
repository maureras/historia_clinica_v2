// src/services/api.ts
export class UnauthorizedError extends Error {
  constructor(message = "UNAUTHORIZED") {
    super(message);
    this.name = "UnauthorizedError";
  }
}

type Query = Record<string, string | number | boolean | null | undefined>;

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";
const TOKEN_KEY = "clinica_token";

/* ===== Token helpers ===== */
export const tokenStore = {
  get(): string | null {
    const raw = localStorage.getItem(TOKEN_KEY) ?? localStorage.getItem("token");
    return raw ? raw.replace(/^"+|"+$/g, "").trim() : null;
  },
  set(token: string) {
    localStorage.setItem(TOKEN_KEY, token);
  },
  clear() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem("token");
  },
};

function buildQuery(params?: Query): string {
  if (!params) return "";
  const esc = encodeURIComponent;
  const entries = Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== "");
  return entries.length ? `?${entries.map(([k, v]) => `${esc(k)}=${esc(String(v))}`).join("&")}` : "";
}

function authHeaders(extra?: HeadersInit, withJson = false): HeadersInit {
  const token = tokenStore.get();
  return {
    Accept: "application/json",
    ...(withJson ? { "Content-Type": "application/json" } : {}),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(extra || {}),
  };
}

async function handleResponse<T>(res: Response): Promise<T> {
  // Intenta parsear JSON, aun en errores
  const text = await res.text();
  const data = text ? (() => { try { return JSON.parse(text); } catch { return text; } })() : null;

  if (res.status === 401) {
    tokenStore.clear();
    throw new UnauthorizedError(typeof data === "object" && data?.error ? data.error : "UNAUTHORIZED");
  }

  if (!res.ok) {
    const msg = typeof data === "object" && (data?.message || data?.error)
      ? (data.message || data.error)
      : `HTTP ${res.status} ${res.statusText}`;
    throw new Error(msg);
  }

  return data as T;
}

/* ===== API surface ===== */
async function get<T>(path: string, opts?: { params?: Query; headers?: HeadersInit }) {
  const url = `${API_URL}${path}${buildQuery(opts?.params)}`;
  const res = await fetch(url, {
    method: "GET",
    credentials: "include",
    headers: authHeaders(opts?.headers),
  });
  return handleResponse<T>(res);
}

async function post<T>(path: string, body?: unknown, opts?: { headers?: HeadersInit }) {
  const res = await fetch(`${API_URL}${path}`, {
    method: "POST",
    credentials: "include",
    headers: authHeaders(opts?.headers, true),
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  return handleResponse<T>(res);
}

async function put<T>(path: string, body?: unknown, opts?: { headers?: HeadersInit }) {
  const res = await fetch(`${API_URL}${path}`, {
    method: "PUT",
    credentials: "include",
    headers: authHeaders(opts?.headers, true),
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  return handleResponse<T>(res);
}

async function patch<T>(path: string, body?: unknown, opts?: { headers?: HeadersInit }) {
  const res = await fetch(`${API_URL}${path}`, {
    method: "PATCH",
    credentials: "include",
    headers: authHeaders(opts?.headers, true),
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  return handleResponse<T>(res);
}

async function del<T>(path: string, opts?: { headers?: HeadersInit }) {
  const res = await fetch(`${API_URL}${path}`, {
    method: "DELETE",
    credentials: "include",
    headers: authHeaders(opts?.headers),
  });
  return handleResponse<T>(res);
}

/** Upload con FormData (NO seteamos Content-Type) */
async function upload<T>(path: string, formData: FormData, opts?: { headers?: HeadersInit }) {
  const res = await fetch(`${API_URL}${path}`, {
    method: "POST",
    credentials: "include",
    headers: authHeaders(opts?.headers), // sin "Content-Type"
    body: formData,
  });
  return handleResponse<T>(res);
}

export const api = { get, post, put, patch, del, upload };
