// src/api/ApiService.ts
import { authService } from '../services/authService';  // ✅ Ruta corregida

const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:4000";

export const apiService = {
  async fetch(endpoint: string, options: RequestInit = {}) {
    const token = authService.getToken();
    
    const headers: Record<string, string> = {  // ✅ Tipo corregido
      'Content-Type': 'application/json',
      ...options.headers as Record<string, string>,
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    return fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers,
    });
  }
};