// =============================================
// File: src/modulos/paciente/PacienteNuevo.tsx
// =============================================
import React, { useState, useEffect, useRef } from "react";
import { 
  User, Phone, Camera, UploadCloud, 
  Save, X, QrCode, ClipboardList, CheckCircle, Download
} from "lucide-react";
import { useNavigate } from "react-router-dom"; // ✅ Importa el hook de router
import QRCode from "qrcode";
import { apiService } from '../api/ApiService';

// URLs del sistema
const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:4000";
const SERVER_URL = import.meta.env.VITE_SERVER_URL ?? API_URL.replace(':4000', ':5173'); // URL del servidor web

// --- INTERFACES ---
export interface PatientData {
  nombres: string;
  apellidos: string;
  numeroIdentificacion: string;
  fechaNacimiento: string;
  sexo: string;
  edad: string;
  email: string;
  telefono: string;
  direccion: string;
  grupoSanguineo: string;
  alergias: string; 
  contactoEmergencia: {
    nombre: string;
    telefono: string;
    relacion: string;
  };
  notas: string;
  foto: string;
}

interface FormularioPacienteProps {
  patient: PatientData;
  onPatientChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onGuardarTodo: () => Promise<number>;
  onCancelar: () => void;
  qrData: string | null;
  qrDisplayData: string | null; // ✅ Nueva prop para mostrar información del usuario
  pacienteId?: number;
  onContactoEmergenciaChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onIrInicio?: () => void;
}

// --- COMPONENTE TOAST ---
const Toast: React.FC<{
  message: string;
  type: 'success' | 'error';
  onClose: () => void;
}> = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 5000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className={`fixed top-4 right-4 z-50 max-w-sm w-full transform transition-all duration-300 ${
      type === 'success' 
        ? 'bg-green-600 text-white' 
        : 'bg-red-600 text-white'
    } rounded-lg shadow-lg p-4`}>
      <div className="flex items-center gap-3">
        {type === 'success' ? <CheckCircle className="h-5 w-5 flex-shrink-0" /> : <X className="h-5 w-5 flex-shrink-0" />}
        <div className="flex-1">
          <p className="text-sm font-medium">{message}</p>
        </div>
        <button onClick={onClose} className="text-white/80 hover:text-white transition-colors">
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

// --- COMPONENTES DE UI ---
const SeccionFormulario: React.FC<{ 
  titulo: string; 
  icono: React.ReactNode; 
  color: string; 
  children: React.ReactNode; 
}> = ({ titulo, icono, color, children }) => (
  <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
    <div className={`${color} border-b px-6 py-4`}>
      <div className="flex items-center gap-3">
        <div className="h-8 w-8 rounded-full bg-white/20 flex items-center justify-center">
          {icono}
        </div>
        <h3 className="font-semibold text-white">{titulo}</h3>
      </div>
    </div>
    <div className="p-6">
      {children}
    </div>
  </div>
);

// ✅ MODIFICADO: Componente QR que muestra información del usuario, no la URL
const QRDisplay: React.FC<{ 
  qrData: string | null; 
  qrDisplayData: string | null; 
  pacienteId?: number 
}> = ({ qrData, qrDisplayData, pacienteId }) => {
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);

  useEffect(() => {
    if (qrData) {
      QRCode.toDataURL(qrData, {
        errorCorrectionLevel: 'H', margin: 2, scale: 6,
        color: { dark: '#020617', light: '#FFFFFFFF' }
      })
      .then(url => setQrCodeUrl(url))
      .catch(err => console.error(err));
    } else {
      setQrCodeUrl(null);
    }
  }, [qrData]);

  const descargarQR = () => {
    if (!qrCodeUrl) return;
    const a = document.createElement("a");
    a.href = qrCodeUrl;
    a.download = `QR_Paciente_${pacienteId || 'temporal'}.png`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  return (
    <SeccionFormulario
      titulo="Código QR - Historia Clínica"
      icono={<QrCode className="h-4 w-4 text-white" />}
      color="bg-gradient-to-r from-slate-500 to-slate-600"
    >
      <div className="text-center">
        {qrCodeUrl ? (
          <div className="space-y-4">
            <div className="flex justify-center">
              <div className="p-3 bg-white rounded-xl border-2 border-slate-200 shadow-sm">
                <img src={qrCodeUrl} alt="Código QR del paciente" className="w-40 h-40" />
              </div>
            </div>
            

            <div className="flex justify-center">
              <button
                type="button"
                onClick={descargarQR}
                className="inline-flex items-center gap-2 rounded-xl bg-slate-700 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-500"
              >
                <Download className="h-4 w-4" /> Descargar QR
              </button>
            </div>
            
            {pacienteId && (
              <div className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-medium bg-green-100 text-green-700 ring-1 ring-green-200">
                <CheckCircle className="h-3 w-3" /> <span>ID: {pacienteId} (Guardado)</span>
              </div>
            )}
            
            {/* ✅ MODIFICADO: Muestra información del usuario, no la URL */}
            {qrDisplayData && (
              <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                <div className="text-xs text-slate-600 font-medium mb-2">Información del Paciente:</div>
                <div className="text-xs text-slate-700 whitespace-pre-line font-mono">
                  {qrDisplayData}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
            <QrCode className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="text-sm text-slate-500">Complete los datos del paciente para generar el código QR de acceso a historia clínica.</p>
          </div>
        )}
      </div>
    </SeccionFormulario>
  );
};

const FotoUploader: React.FC<{ foto: string; onFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void }> = ({ foto, onFileChange }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  return (
    <SeccionFormulario
      titulo="Fotografía del Paciente"
      icono={<Camera className="h-4 w-4 text-white" />}
      color="bg-gradient-to-r from-sky-500 to-sky-600"
    >
      <div className="flex flex-col items-center gap-4">
        <div className="h-40 w-40 rounded-full bg-slate-100 flex items-center justify-center overflow-hidden border-4 border-white shadow-md">
          {foto ? (
            <img src={foto} alt="Foto del paciente" className="w-full h-full object-cover" />
          ) : (
            <User className="h-20 w-20 text-slate-400" />
          )}
        </div>
        <input type="file" accept="image/*" onChange={onFileChange} ref={fileInputRef} className="hidden" />
        <button
          onClick={() => fileInputRef.current?.click()}
          className="inline-flex items-center gap-2 w-full justify-center rounded-xl bg-white px-4 py-2 text-sm font-medium text-sky-700 shadow-sm ring-1 ring-inset ring-slate-200 hover:bg-slate-50"
        >
          <UploadCloud className="h-4 w-4" /> {foto ? 'Cambiar Fotografía' : 'Subir Fotografía'}
        </button>
      </div>
    </SeccionFormulario>
  );
};

// --- FORMULARIO PRINCIPAL ---
const FormularioPaciente: React.FC<FormularioPacienteProps> = ({
  patient,
  onPatientChange,
  onFileChange,
  onGuardarTodo,
  onCancelar,
  qrData,
  qrDisplayData,
  pacienteId,
  onContactoEmergenciaChange,
  onIrInicio,
}) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [toast, setToast] = useState<{message: string; type: 'success' | 'error'} | null>(null);
  const navigate = useNavigate();

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setToast(null);
    try {
      const newId = await onGuardarTodo();
      setToast({ message: `¡Paciente guardado exitosamente! ID: ${newId}`, type: 'success' });
    } catch (err: any) {
      setToast({ message: err.message || "Ocurrió un error al guardar.", type: 'error' });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="min-h-screen bg-slate-50">
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}

      <div className="mx-auto max-w-7xl px-4 py-8">
        {/* Header con botón a la derecha */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-slate-900 mb-2">
              Registrar Nuevo Paciente
            </h1>
            <p className="text-lg text-slate-600">
              Complete los campos para añadir un nuevo paciente al sistema.
            </p>
          </div>

          {/* Botón página principal */}
          <button
            type="button"
            onClick={() => navigate("/")}
            className="inline-flex items-center gap-2 rounded-xl bg-slate-700 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-500"
          >
            Página principal
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <SeccionFormulario
              titulo="Información Personal"
              icono={<User className="h-4 w-4 text-white" />}
              color="bg-gradient-to-r from-blue-500 to-blue-600"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Nombres</label>
                  <input type="text" name="nombres" value={patient.nombres} onChange={onPatientChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Apellidos</label>
                  <input type="text" name="apellidos" value={patient.apellidos} onChange={onPatientChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-2">Número de Identificación (Cédula)</label>
                  <input type="text" name="numeroIdentificacion" value={patient.numeroIdentificacion} onChange={onPatientChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Edad</label>
                  <input type="number" name="edad" min={0} value={patient.edad} onChange={onPatientChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Fecha de Nacimiento</label>
                  <input type="date" name="fechaNacimiento" value={patient.fechaNacimiento} onChange={onPatientChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Sexo</label>
                  <select name="sexo" value={patient.sexo} onChange={onPatientChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Seleccionar...</option>
                    <option value="Masculino">Masculino</option>
                    <option value="Femenino">Femenino</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Grupo Sanguíneo</label>
                  <select name="grupoSanguineo" value={patient.grupoSanguineo} onChange={onPatientChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Seleccionar...</option>
                    {["O+","O-","A+","A-","B+","B-","AB+","AB-"].map(gs => (
                      <option key={gs} value={gs}>{gs}</option>
                    ))}
                  </select>
                </div>
              </div>
            </SeccionFormulario>

            <SeccionFormulario
              titulo="Información de Contacto"
              icono={<Phone className="h-4 w-4 text-white" />}
              color="bg-gradient-to-r from-emerald-500 to-emerald-600"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                  <input type="email" name="email" value={patient.email} onChange={onPatientChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Teléfono</label>
                  <input type="tel" name="telefono" value={patient.telefono} onChange={onPatientChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-2">Dirección</label>
                  <input type="text" name="direccion" value={patient.direccion} onChange={onPatientChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500" />
                </div>
              </div>
              <div className="mt-6">
                <h4 className="text-sm font-semibold text-slate-900 uppercase tracking-wide mb-3">Contacto de emergencia</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Nombre</label>
                    <input type="text" name="nombre" value={patient.contactoEmergencia.nombre} onChange={onContactoEmergenciaChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Teléfono</label>
                    <input type="tel" name="telefono" value={patient.contactoEmergencia.telefono} onChange={onContactoEmergenciaChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Relación</label>
                    <input type="text" name="relacion" value={patient.contactoEmergencia.relacion} onChange={onContactoEmergenciaChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500" />
                  </div>
                </div>
              </div>
            </SeccionFormulario>

            <SeccionFormulario
              titulo="Información Médica Básica"
              icono={<ClipboardList className="h-4 w-4 text-white" />}
              color="bg-gradient-to-r from-rose-500 to-rose-600"
            >
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Alergias</label>
                  <textarea
                    name="alergias"
                    value={patient.alergias}
                    onChange={onPatientChange}
                    rows={3}
                    placeholder="Liste las alergias separadas por comas (ej: Polen, Penicilina)..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>
            </SeccionFormulario>

            <SeccionFormulario
              titulo="Notas Adicionales"
              icono={<ClipboardList className="h-4 w-4 text-white" />}
              color="bg-gradient-to-r from-amber-500 to-amber-600"
            >
              <textarea
                name="notas"
                value={patient.notas}
                onChange={onPatientChange}
                rows={4}
                placeholder="Condiciones preexistentes, observaciones, etc."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </SeccionFormulario>
          </div>

          <div className="lg:col-span-1 space-y-8">
            <FotoUploader foto={patient.foto} onFileChange={onFileChange} />
            <QRDisplay 
              qrData={qrData} 
              qrDisplayData={qrDisplayData}
              pacienteId={pacienteId} 
            />
          </div>
        </div>
        
        {/* === Botonera corregida (3 botones, sin anidar) === */}
        <div className="flex items-center justify-end gap-4 pt-8 mt-8 border-t border-slate-200">
          <button
            onClick={onCancelar}
            disabled={isSubmitting}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-6 py-3 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50 transition-colors disabled:opacity-50"
          >
            <X className="h-4 w-4" /> Cancelar
          </button>

          <button
            type="button"
            onClick={onIrInicio ?? (() => (window.location.href = '/'))}
            className="inline-flex items-center gap-2 rounded-xl bg-slate-700 px-6 py-3 text-sm font-medium text-white shadow-sm hover:bg-slate-800 transition-colors"
          >
            Página principal
          </button>

          <button
            onClick={handleSubmit}
            disabled={isSubmitting || !patient.nombres || !patient.apellidos || !patient.numeroIdentificacion}
            className={`inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-medium shadow-sm transition-all disabled:opacity-50 ${
              toast?.type === 'success'
                ? 'bg-green-600 hover:bg-green-700 text-white'
                : 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white disabled:from-slate-400 disabled:to-slate-500'
            }`}
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                Guardando...
              </>
            ) : toast?.type === 'success' ? (
              <>
                <CheckCircle className="h-4 w-4" /> ¡Guardado!
              </>
            ) : (
              <>
                <Save className="h-4 w-4" /> Guardar Paciente
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

// --- CONTENEDOR DE LÓGICA ---
const PacienteNuevo: React.FC = () => {
  const navigate = useNavigate();

  const [paciente, setPaciente] = useState<PatientData>({
    nombres: "",
    apellidos: "",
    numeroIdentificacion: "",
    fechaNacimiento: "",
    sexo: "",
    edad: "",
    email: "",
    telefono: "",
    direccion: "",
    grupoSanguineo: "",
    alergias: "",
    contactoEmergencia: { nombre: "", telefono: "", relacion: "" },
    notas: "",
    foto: "",
  });

  const [qrData, setQrData] = useState<string | null>(null); // URL del servidor para el QR
  const [qrDisplayData, setQrDisplayData] = useState<string | null>(null); // Información del usuario para mostrar
  const [pacienteId, setPacienteId] = useState<number | undefined>();

  // ✅ MODIFICADO: Genera URL del servidor y datos de visualización separados
  useEffect(() => {
    if (paciente.nombres.trim() && paciente.apellidos.trim()) {
      // 1. URL para el QR (apunta al servidor)
      let serverURL = SERVER_URL;
      let qrURL;
      
      if (pacienteId) {
        // URL directa con ID del paciente guardado
        qrURL = `${serverURL}/historia?paciente=${pacienteId}`;
      } else {
        // URL con búsqueda por nombre mientras no tenga ID
        const nombreCompleto = `${paciente.nombres} ${paciente.apellidos}`.trim();
        qrURL = `${serverURL}/historia?q=${encodeURIComponent(nombreCompleto)}`;
      }
      setQrData(qrURL);

      // 2. Información del usuario para mostrar (sin URL)
      let displayInfo;
      if (pacienteId) {
        displayInfo = `ID: ${pacienteId}\nNombre: ${paciente.nombres} ${paciente.apellidos}\nCI: ${paciente.numeroIdentificacion}`;
      } else {
        displayInfo = `Nombre: ${paciente.nombres} ${paciente.apellidos}\nCI: ${paciente.numeroIdentificacion || 'Pendiente'}`;
      }
      
      // Agregar información adicional si está disponible
      if (paciente.telefono) {
        displayInfo += `\nTeléfono: ${paciente.telefono}`;
      }
      if (paciente.email) {
        displayInfo += `\nEmail: ${paciente.email}`;
      }
      
      setQrDisplayData(displayInfo);
    } else {
      setQrData(null);
      setQrDisplayData(null);
    }
  }, [paciente.nombres, paciente.apellidos, paciente.numeroIdentificacion, paciente.telefono, paciente.email, pacienteId]);

  const onPatientChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPaciente(prev => ({ ...prev, [name]: value }));
  };

  const onContactoEmergenciaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPaciente(prev => ({
      ...prev,
      contactoEmergencia: { ...prev.contactoEmergencia, [name]: value }
    }));
  };

  const onArchivoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setPaciente(prev => ({ ...prev, foto: String(reader.result) }));
    reader.readAsDataURL(file);
  };

  const guardarTodo = async (): Promise<number> => {
    if (!paciente.nombres.trim() || !paciente.apellidos.trim() || !paciente.numeroIdentificacion.trim()) {
      throw new Error('Nombres, Apellidos y Número de Identificación son obligatorios.');
    }
  
    const alergiasArray = paciente.alergias.split(',')
      .map(alergia => alergia.trim())
      .filter(alergia => alergia);

    // ✅ MODIFICADO: Usa la URL del servidor para guardar en BD
    const qrText = qrData || `${SERVER_URL}/historia?q=${encodeURIComponent(paciente.nombres + ' ' + paciente.apellidos)}`;
    let qrPng: string | null = null;
    try {
      qrPng = await QRCode.toDataURL(qrText);
    } catch (e) {
      console.warn('No se pudo generar PNG del QR', e);
    }

    const payloadLimpio = {
      ...paciente,
      alergias: alergiasArray,
      fechaNacimiento: paciente.fechaNacimiento || null,
      edad: paciente.edad ? parseInt(paciente.edad, 10) : null,
      qrData: qrText, // ✅ URL del servidor
      qrCode: qrPng,
    };

    const resp = await apiService.fetch('/api/pacientes', {
      method: "POST",
      body: JSON.stringify(payloadLimpio),
    });

    if (!resp.ok) {
      const error = await resp.json().catch(() => ({}));
      throw new Error(error?.message || `Error HTTP ${resp.status}`);
    }

    const result = await resp.json();
    const newId = result?.data?.id;
    if (!newId) {
      throw new Error("El servidor no devolvió un ID válido.");
    }

    setPacienteId(newId);
    return newId;
  };

  const cancelar = () => navigate("/", { replace: true });
  const irInicio = () => navigate("/", { replace: true });

  return (
    <FormularioPaciente
      patient={paciente}
      onPatientChange={onPatientChange}
      onFileChange={onArchivoChange}
      qrData={qrData}
      qrDisplayData={qrDisplayData}
      pacienteId={pacienteId}
      onGuardarTodo={guardarTodo}
      onCancelar={cancelar}
      onContactoEmergenciaChange={onContactoEmergenciaChange}
      onIrInicio={irInicio}
    />
  );
};

export default PacienteNuevo;