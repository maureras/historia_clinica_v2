import React, { useEffect, useMemo, useState, useRef } from "react";
import type { ReactNode } from "react";
import { 
  Search, User, Calendar, Stethoscope, ClipboardList, FileText, Pill, Activity, 
  TestTube, CheckCircle2, Clock, X, QrCode, CreditCard,
  Mail, Users, Download, AlertCircle, Phone, MapPin,
  Heart, Droplets, UserCheck, Shield, Edit, Eye, Star, Hash
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { authService } from "@/services/authService";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";
const SERVER_URL = import.meta.env.VITE_SERVER_URL ?? API_URL.replace(':4000', ':5173'); // URL del servidor web

/* ========= AUTH HELPERS ========= */
const withAuth = (opts: RequestInit = {}): RequestInit => {
  const token = authService.getToken?.();
  return {
    credentials: "include",
    ...opts,
    headers: {
      Accept: "application/json",
      ...(opts.headers || {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  };
};

// --- TIPOS ---
export type Evento = { 
  id: string | number; 
  tipo: string; 
  fecha: string; 
  resumen?: string; 
  notas?: string | null; 
  diagnostico?: string; 
  tratamiento?: string | null; 
  medicamentos?: string | null; 
  siguienteCita?: string | null; 
  detalles?: any; 
};

export type Paciente = { 
  id: string; 
  nombre: string; 
  edad?: number; 
  cedula?: string; 
  telefono?: string; 
  email?: string; 
  direccion?: string; 
  fechaNacimiento?: string; 
  grupoSanguineo?: string; 
  alergias?: string[]; 
  contactoEmergencia?: { 
    nombre: string; 
    telefono: string; 
    relacion: string; 
  }; 
  // QR desde backend (como en NuevaConsulta)
  qrCode?: string;   // URL/dataURL del QR generado por el backend
  qrData?: string;   // payload del QR (texto/JSON)
};

export type LineaTiempoResponse = { 
  paciente: Paciente | null; 
  eventos: Evento[]; 
};

export type PacienteSugerencia = { 
  id: string; 
  nombre: string; 
  cedula?: string; 
  telefono?: string; 
  ultimaVisita?: string; 
};

// --- HELPERS ---
function classNames(...xs: Array<string | false | null | undefined>) { 
  return xs.filter(Boolean).join(" "); 
}

function formatFecha(fechaISO: string) { 
  const d = new Date(fechaISO); 
  return new Intl.DateTimeFormat("es-EC", { 
    day: "2-digit", 
    month: "long", 
    year: "numeric" 
  }).format(d); 
}

function formatFechaCompleta(fechaISO: string) { 
  const d = new Date(fechaISO); 
  return new Intl.DateTimeFormat("es-EC", { 
    weekday: "long", 
    day: "2-digit", 
    month: "long", 
    year: "numeric", 
    hour: '2-digit', 
    minute: '2-digit' 
  }).format(d); 
}

function badgeColorByTipo(tipo: string) { 
  const t = tipo.toLowerCase(); 
  if (t.includes("padecimiento")) return "bg-blue-100 text-blue-700 ring-blue-200"; 
  if (t.includes("signos vitales")) return "bg-red-100 text-red-700 ring-red-200"; 
  if (t.includes("exploración")) return "bg-purple-100 text-purple-700 ring-purple-200"; 
  if (t.includes("diagnóstico")) return "bg-amber-100 text-amber-700 ring-amber-200"; 
  if (t.includes("tratamiento")) return "bg-emerald-100 text-emerald-700 ring-emerald-200"; 
  if (t.includes("laboratorio")) return "bg-indigo-100 text-indigo-700 ring-indigo-200";
  if (t.includes("consulta")) return "bg-blue-100 text-blue-700 ring-blue-200";
  if (t.includes("exámenes")) return "bg-indigo-100 text-indigo-700 ring-indigo-200";
  return "bg-slate-100 text-slate-700 ring-slate-200"; 
}

function iconByTipo(tipo: string): ReactNode { 
  const t = tipo.toLowerCase(); 
  if (t.includes("padecimiento")) return <ClipboardList className="h-5 w-5" />; 
  if (t.includes("signos vitales")) return <Activity className="h-5 w-5" />; 
  if (t.includes("exploración")) return <Stethoscope className="h-5 w-5" />; 
  if (t.includes("diagnóstico")) return <ClipboardList className="h-5 w-5" />; 
  if (t.includes("tratamiento")) return <Pill className="h-5 w-5" />; 
  if (t.includes("laboratorio")) return <TestTube className="h-5 w-5" />;
  if (t.includes("consulta")) return <Stethoscope className="h-5 w-5" />;
  if (t.includes("exámenes")) return <TestTube className="h-5 w-5" />;
  return <FileText className="h-5 w-5" />; 
}

// Función para detectar homónimos
function detectarHomonimos(pacientes: PacienteSugerencia[]) {
  const nombres = pacientes.map(p => p.nombre.toLowerCase());
  return pacientes.map((paciente) => {
    const nombre = paciente.nombre.toLowerCase();
    const esHomonimo = nombres.filter(n => n === nombre).length > 1;
    return { ...paciente, esHomonimo };
  });
}

/* ========== API (con AUTH y manejo 401) ========== */
async function buscarPacientesAPI(query: string): Promise<PacienteSugerencia[]> {
  try {
    if (!query || query.length < 2) return [];
    const resp = await fetch(
      `${API_URL}/api/historia/buscar?q=${encodeURIComponent(query)}`,
      withAuth({ method: "GET" })
    );
    if (resp.status === 401) {
      // Asegura limpiar sesión
      authService.logout().catch(() => {});
      throw new Error("UNAUTHORIZED");
    }
    if (!resp.ok) {
      throw new Error(`Error ${resp.status}: ${resp.statusText}`);
    }
    const data = await resp.json();
    return Array.isArray(data) ? data : [];
  } catch (error) {
    console.error("Error buscando pacientes:", error);
    throw error;
  }
}

async function obtenerLineaTiempoAPI(pacienteId: string): Promise<LineaTiempoResponse | null> {
  try {
    const resp = await fetch(
      `${API_URL}/api/historia/paciente/${pacienteId}`,
      withAuth({ method: "GET" })
    );
    if (resp.status === 401) {
      authService.logout().catch(() => {});
      throw new Error("UNAUTHORIZED");
    }
    if (!resp.ok) {
      throw new Error(`Error ${resp.status}: ${resp.statusText}`);
    }
    return await resp.json();
  } catch (error) {
    console.error("Error obteniendo línea de tiempo:", error);
    throw error;
  }
}
/* ======================================================= */

// --- COMPONENTES ---

function EventoModal({ evento, paciente, isOpen, onClose }: {
  evento: Evento | null;
  paciente: Paciente | null;
  isOpen: boolean;
  onClose: () => void;
}) {
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  if (!isOpen || !evento) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="fixed inset-0 bg-black bg-opacity-50 transition-opacity" onClick={onClose} />
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative w-full max-w-4xl transform rounded-2xl bg-white shadow-2xl transition-all">
          <div className="flex items-center justify-between border-b border-gray-200 px-6 py-4">
            <div className="flex items-center gap-3">
              <div className={classNames("inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-sm font-medium ring-1", badgeColorByTipo(evento.tipo))}>
                {iconByTipo(evento.tipo)}
                <span>{evento.tipo}</span>
              </div>
            </div>
            <button onClick={onClose} className="rounded-lg p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-600 focus:outline-none focus:ring-2 focus:ring-sky-500">
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="max-h-[80vh] overflow-y-auto px-6 py-6 space-y-6">
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">Fecha del Evento</h3>
                <div className="flex items-center gap-2 text-slate-600">
                  <Calendar className="h-4 w-4" />
                  {formatFechaCompleta(evento.fecha)}
                </div>
              </div>

              {evento.resumen && (
                <div>
                  <h3 className="text-lg font-semibold mb-2">Resumen</h3>
                  <p className="text-slate-700 bg-slate-50 rounded-lg p-4">{evento.resumen}</p>
                </div>
              )}

              {evento.diagnostico && (
                <div>
                  <h3 className="text-lg font-semibold mb-2">Diagnóstico</h3>
                  <p className="text-slate-700 bg-amber-50 border border-amber-200 rounded-lg p-4">{evento.diagnostico}</p>
                </div>
              )}

              {evento.tratamiento && (
                <div>
                  <h3 className="text-lg font-semibold mb-2">Tratamiento</h3>
                  <p className="text-slate-700 bg-green-50 border border-green-200 rounded-lg p-4">{evento.tratamiento}</p>
                </div>
              )}

              {evento.medicamentos && (
                <div>
                  <h3 className="text-lg font-semibold mb-2">Medicamentos</h3>
                  <p className="text-slate-700 bg-blue-50 border border-blue-200 rounded-lg p-4">{evento.medicamentos}</p>
                </div>
              )}

              {evento.notas && (
                <div>
                  <h3 className="text-lg font-semibold mb-2">Notas Adicionales</h3>
                  <p className="text-slate-700 bg-slate-50 rounded-lg p-4">{evento.notas}</p>
                </div>
              )}

              {/* detalles laboratorio */}
              {evento.detalles?.tipo === 'laboratorio' && evento.detalles.resultados && (
                <div>
                  <h3 className="text-lg font-semibold mb-2">Resultados de Laboratorio</h3>
                  <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {evento.detalles.resultados.map((resultado: any, index: number) => (
                        <div key={index} className="bg-white rounded-lg p-3 border">
                          <div className="font-medium text-indigo-900">{resultado.prueba}</div>
                          <div className="text-sm text-slate-600">
                            <span className="font-semibold">{resultado.valor}</span>
                            {resultado.unidad && <span> {resultado.unidad}</span>}
                            {resultado.rango && <span className="text-slate-500"> (Ref: {resultado.rango})</span>}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
          <div className="border-t border-gray-200 px-6 py-4 flex justify-end">
            <button onClick={onClose} className="rounded-lg bg-slate-100 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-500">
              Cerrar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function BusquedaPaciente({ valorBusqueda, onCambioBusqueda, sugerencias, onSeleccionarSugerencia, historial, onSeleccionarHistorial, onLimpiarHistorial, loading }: { 
  valorBusqueda: string; 
  onCambioBusqueda: (valor: string) => void; 
  sugerencias: PacienteSugerencia[]; 
  onSeleccionarSugerencia: (paciente: PacienteSugerencia) => void; 
  historial: PacienteSugerencia[]; 
  onSeleccionarHistorial: (paciente: PacienteSugerencia) => void; 
  onLimpiarHistorial: () => void; 
  loading: boolean; 
}) {
  const [mostrarSugerencias, setMostrarSugerencias] = useState(false);
  const [mostrarHistorial, setMostrarHistorial] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const valor = e.target.value;
    onCambioBusqueda(valor);
    setMostrarSugerencias(valor.length > 0);
    setSelectedIndex(-1);
    if (valor.length === 0 && historial.length > 0) {
      setMostrarHistorial(true);
    } else {
      setMostrarHistorial(false);
    }
  };

  const handleFocus = () => {
    if (valorBusqueda.length > 0 && sugerencias.length > 0) {
      setMostrarSugerencias(true);
    } else if (historial.length > 0) {
      setMostrarHistorial(true);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    const items = mostrarSugerencias ? sugerencias : historial;
    if (!items.length) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => prev < items.length - 1 ? prev + 1 : prev);
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => prev > 0 ? prev - 1 : -1);
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && selectedIndex < items.length) {
          const paciente = items[selectedIndex];
          if (mostrarSugerencias) {
            onSeleccionarSugerencia(paciente);
            setMostrarSugerencias(false);
          } else {
            onSeleccionarHistorial(paciente);
            setMostrarHistorial(false);
          }
        }
        break;
      case 'Escape':
        setMostrarSugerencias(false);
        setMostrarHistorial(false);
        setSelectedIndex(-1);
        break;
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setMostrarSugerencias(false);
        setMostrarHistorial(false);
        setSelectedIndex(-1);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const sugerenciasConHomonimos = detectarHomonimos(sugerencias);

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-visible">
      <div className="bg-slate-50 border-b border-slate-200 px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center">
            <Search className="h-4 w-4 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-900">Buscar Paciente</h3>
            <p className="text-sm text-slate-600">Busque en el historial clínico de cualquier paciente</p>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="space-y-4">
          <div className="relative" ref={dropdownRef}>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-slate-400" />
              </div>
              
              <input 
                type="text" 
                placeholder="Escriba el nombre o cédula del paciente..." 
                className="block w-full pl-10 pr-10 py-3 border border-slate-300 rounded-xl shadow-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:border-slate-500 sm:text-sm" 
                value={valorBusqueda} 
                onChange={handleInputChange} 
                onFocus={handleFocus}
                onKeyDown={handleKeyDown}
              />
              
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center gap-2">
                {loading && (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-slate-600"></div>
                )}
                {valorBusqueda && !loading && (
                  <button
                    onClick={() => onCambioBusqueda("")}
                    className="text-slate-400 hover:text-slate-600"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>

            {(mostrarSugerencias || mostrarHistorial) && (
              <div 
                className="absolute z-[9999] mt-1 w-full bg-white shadow-2xl max-h-80 rounded-xl py-1 text-base ring-1 ring-black ring-opacity-10 overflow-auto border border-slate-200"
                style={{ zIndex: 99999 }}
              >
                {/* SUGERENCIAS */}
                {mostrarSugerencias && sugerencias.length > 0 && (
                  <div>
                    <div className="px-4 py-2 bg-slate-50 border-b border-slate-200">
                      <div className="flex items-center gap-2 text-xs text-slate-700">
                        <Search className="h-3 w-3" />
                        <span>Pacientes encontrados ({sugerencias.length})</span>
                      </div>
                    </div>
                    {sugerenciasConHomonimos.map((p: any, index: number) => (
                      <div
                        key={p.id} 
                        onClick={() => { 
                          onSeleccionarSugerencia(p); 
                          setMostrarSugerencias(false); 
                          setSelectedIndex(-1);
                        }} 
                        className={`cursor-pointer select-none flex w-full items-center gap-4 px-4 py-4 hover:bg-slate-50 border-b last:border-b-0 transition-all ${
                          index === selectedIndex ? 'bg-slate-50' : ''
                        }`}
                      >
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100">
                          <User className="h-5 w-5 text-slate-500" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <div className="font-medium truncate">{p.nombre}</div>
                            {p.esHomonimo && (
                              <div className="flex items-center gap-1 px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full text-xs">
                                <AlertCircle className="h-3 w-3" />
                                <span>Homónimo</span>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-3 text-sm text-slate-500">
                            <span>ID: {p.id}</span>
                            {p.cedula && <span>CI: {p.cedula}</span>}
                            {p.telefono && <span>{p.telefono}</span>}
                            {p.ultimaVisita && <span>Última: {formatFecha(p.ultimaVisita)}</span>}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                {/* HISTORIAL - Exactamente como el fragmento original */}
                {mostrarHistorial && historial.length > 0 && (
                  <div>
                    <div className="px-4 py-2 bg-slate-50 border-b border-slate-200">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-xs text-slate-700">
                          <Clock className="h-3 w-3" />
                          <span>Búsquedas recientes</span>
                        </div>
                        <button 
                          onClick={onLimpiarHistorial} 
                          className="text-xs text-slate-400 hover:text-slate-600"
                        >
                          Limpiar
                        </button>
                      </div>
                    </div>
                    {historial.map((p, index) => (
                      <div
                        key={p.id} 
                        onClick={() => { 
                          onSeleccionarHistorial(p); 
                          setMostrarHistorial(false);
                          setSelectedIndex(-1); 
                        }} 
                        className={`cursor-pointer select-none flex w-full items-center gap-4 px-4 py-4 hover:bg-slate-50 border-b last:border-b-0 transition-all ${
                          index === selectedIndex ? 'bg-slate-50' : ''
                        }`}
                      >
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100">
                          <Clock className="h-5 w-5 text-slate-500" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium truncate">{p.nombre}</div>
                          <div className="flex items-center gap-3 text-sm text-slate-500">
                            {p.cedula && <span>CI: {p.cedula}</span>}
                            {p.ultimaVisita && <span>Última visita: {formatFecha(p.ultimaVisita)}</span>}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                {/* Sin resultados */}
                {mostrarSugerencias && sugerencias.length === 0 && !loading && (
                  <div className="px-4 py-8 text-center text-sm text-slate-500">
                    <Users className="mx-auto h-8 w-8 text-slate-300 mb-2" />
                    No se encontraron pacientes
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ===================== NUEVO COMPONENTE DE RESUMEN =====================
const PacienteSeleccionadoResumen: React.FC<{
  paciente: PacienteSugerencia;
  onLimpiar: () => void;
}> = ({ paciente, onLimpiar }) => {
  return (
    <div className="p-4 bg-green-50 border border-green-200 rounded-xl">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-full bg-green-600 flex items-center justify-center">
            <UserCheck className="h-5 w-5 text-white" />
          </div>
          <div>
            <div className="text-xs font-medium text-green-700">Paciente seleccionado</div>
            <div className="font-semibold text-green-900">{paciente.nombre}</div>
            <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-green-700">
              <span className="inline-flex items-center gap-1">
                <Hash className="h-3 w-3" />
                ID: {paciente.id}
              </span>
              {paciente.cedula && (
                <span className="inline-flex items-center gap-1">
                  <CreditCard className="h-3 w-3" />
                  CI: <span className="font-mono">{paciente.cedula}</span>
                </span>
              )}
            </div>
          </div>
        </div>
        <button
          onClick={onLimpiar}
          className="inline-flex items-center gap-2 rounded-lg border border-green-200 bg-white/70 px-3 py-2 text-sm font-medium text-green-700 hover:bg-white hover:text-green-900 transition-colors"
          title="Quitar paciente seleccionado"
        >
          <X className="h-4 w-4" />
          Quitar
        </button>
      </div>
    </div>
  );
};


const QRDisplayHistoria: React.FC<{ paciente: Paciente }> = ({ paciente }) => {
  const [src, setSrc] = useState<string | null>(null);
  const [qrError, setQrError] = useState(false);

  // payload para fallback
  const datosQR = useMemo(
    () =>
      paciente.qrData ||
      JSON.stringify({ id: paciente.id, nombre: paciente.nombre, cedula: paciente.cedula }),
    [paciente]
  );

  const fallbackSrc = useMemo(
    () =>
      `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(
        datosQR
      )}`,
    [datosQR]
  );

  useEffect(() => {
    let objectUrlToRevoke: string | null = null;
    setQrError(false);

    const loadQR = async () => {
      const raw = paciente.qrCode;
      if (!raw) {
        setSrc(fallbackSrc);
        return;
      }

      // Normaliza a URL absoluta si viene relativa
      const abs = /^(data:|https?:\/\/)/i.test(raw)
        ? raw
        : `${API_URL.replace(/\/+$/, '')}/${String(raw).replace(/^\/+/, '')}`;

      // Si es data: úsalo tal cual
      if (abs.startsWith('data:')) {
        setSrc(abs);
        return;
      }

      try {
        // Prefetch con AUTH -> blob URL para que <img> no necesite el header
        const resp = await fetch(abs, withAuth({ method: 'GET', cache: 'no-store', mode: 'cors' }));
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const blob = await resp.blob();
        const url = URL.createObjectURL(blob);
        objectUrlToRevoke = url;
        setSrc(url);
      } catch (e) {
        console.warn('Fallo cargando QR protegido, usando fallback:', e);
        setQrError(true);
        setSrc(fallbackSrc);
      }
    };

    loadQR();

    return () => {
      if (objectUrlToRevoke) URL.revokeObjectURL(objectUrlToRevoke);
    };
  }, [paciente.qrCode, fallbackSrc]);

  const descargarQR = () => {
    const a = document.createElement('a');
    a.href = src || fallbackSrc;
    a.download = `QR_${paciente.nombre.replace(/\s+/g, '_')}.png`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  return (
    <div className="text-center">
      <div className="inline-flex items-center gap-2 text-emerald-700 font-medium mb-3">
        <QrCode className="w-4 h-4" />
        <span className="text-sm">Código QR</span>
      </div>

      {src ? (
        <div className="space-y-2">
          <div className="flex justify-center">
            <div className="p-3 bg-white rounded-xl border-2 border-emerald-200 shadow-sm">
              <img
                src={src}
                alt="Código QR del paciente"
                className="w-32 h-32"
                onError={() => {
                  setQrError(true);
                  setSrc(fallbackSrc);
                }}
              />
            </div>
          </div>

          {paciente.qrData && (
            <p className="text-xs text-slate-500 font-mono break-all">
              {paciente.qrData}
            </p>
          )}

          {qrError && (
            <div className="text-[11px] text-amber-600">Mostrando QR alternativo</div>
          )}
        </div>
      ) : (
        <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
          <QrCode className="w-8 h-8 text-slate-400 mx-auto mb-2" />
          <p className="text-sm text-slate-500">
            {qrError ? 'Error cargando QR' : 'Cargando...'}
          </p>
        </div>
      )}
    </div>
  );
};



function VisualizacionPaciente({ paciente }: { paciente: Paciente }) {
  const [qrError, setQrError] = useState(false);

  const datosQR = useMemo(
    () =>
      paciente.qrData ||
      JSON.stringify({ id: paciente.id, nombre: paciente.nombre, cedula: paciente.cedula }),
    [paciente]
  );

  const fallbackQR = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(
    datosQR
  )}`;

  const qrSrc = !qrError && paciente.qrCode ? paciente.qrCode : fallbackQR;

  const descargarQR = async () => {
    try {
      const resp = await fetch(qrSrc, { mode: 'cors', cache: 'no-store' });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const blob = await resp.blob();
      const objectUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = objectUrl;
      a.download = `QR_${paciente.nombre.replace(/\s+/g, '_')}.png`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(objectUrl);
    } catch (e) {
      console.error('No se pudo descargar el QR', e);
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
        <div className="bg-gradient-to-r from-sky-50 to-blue-50 border-b border-sky-200 px-6 py-6">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center">
                <User className="h-8 w-8 text-white" />
              </div>
              <div className="absolute -top-1 -right-1 h-6 w-6 bg-green-500 text-white rounded-full flex items-center justify-center text-xs font-bold">
                <UserCheck className="h-3 w-3" />
              </div>
            </div>

            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-2xl font-bold text-sky-900">{paciente.nombre}</h2>
                <div className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-medium bg-sky-100 text-sky-700 ring-1 ring-sky-200">
                  <Star className="h-3 w-3" />
                  <span>Paciente Activo</span>
                </div>
              </div>
              <div className="flex items-center gap-4 text-sm text-sky-700">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  <span className="font-medium">ID: {paciente.id}</span>
                </div>
                {paciente.cedula && (
                  <div className="flex items-center gap-2">
                    <CreditCard className="h-4 w-4" />
                    <span className="font-mono">{paciente.cedula}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex gap-2">
              <button className="inline-flex items-center gap-2 rounded-xl bg-white/80 px-3 py-2 text-sm font-medium text-sky-700 hover:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500">
                <Edit className="h-4 w-4" />
                Editar
              </button>
              <button className="inline-flex items-center gap-2 rounded-xl bg-sky-600 px-3 py-2 text-sm font-medium text-white hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500">
                <Eye className="h-4 w-4" />
                Ver Todo
              </button>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Información Personal */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-slate-900 uppercase tracking-wide">Información Personal</h4>

              {typeof paciente.edad === 'number' && (
                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                  <div className="h-10 w-10 rounded-lg bg-slate-100 flex items-center justify-center">
                    <Calendar className="h-5 w-5 text-slate-600" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 font-medium">Edad</div>
                    <div className="text-base font-semibold text-slate-900">{paciente.edad} años</div>
                  </div>
                </div>
              )}

              {paciente.fechaNacimiento && (
                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                  <div className="h-10 w-10 rounded-lg bg-slate-100 flex items-center justify-center">
                    <Calendar className="h-5 w-5 text-slate-600" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 font-medium">Fecha de Nacimiento</div>
                    <div className="text-base font-semibold text-slate-900">{formatFecha(paciente.fechaNacimiento)}</div>
                  </div>
                </div>
              )}

              {paciente.grupoSanguineo && (
                <div className="flex items-center gap-3 p-3 bg-red-50 rounded-xl">
                  <div className="h-10 w-10 rounded-lg bg-red-100 flex items-center justify-center">
                    <Droplets className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <div className="text-xs text-red-500 font-medium">Grupo Sanguíneo</div>
                    <div className="text-base font-semibold text-red-900">{paciente.grupoSanguineo}</div>
                  </div>
                </div>
              )}
            </div>

            {/* Contacto */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-slate-900 uppercase tracking-wide">Contacto</h4>

              {paciente.telefono && (
                <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl">
                  <div className="h-10 w-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <Phone className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <div className="text-xs text-blue-500 font-medium">Teléfono</div>
                    <div className="text-base font-semibold text-blue-900">{paciente.telefono}</div>
                  </div>
                </div>
              )}

              {paciente.email && (
                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-xl">
                  <div className="h-10 w-10 rounded-lg bg-green-100 flex items-center justify-center">
                    <Mail className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <div className="text-xs text-green-500 font-medium">Email</div>
                    <div className="text-base font-semibold text-green-900">{paciente.email}</div>
                  </div>
                </div>
              )}

              {paciente.direccion && (
                <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-xl">
                  <div className="h-10 w-10 rounded-lg bg-purple-100 flex items-center justify-center">
                    <MapPin className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <div className="text-xs text-purple-500 font-medium">Dirección</div>
                    <div className="text-base font-semibold text-purple-900">{paciente.direccion}</div>
                  </div>
                </div>
              )}
            </div>

            {/* Información Médica */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-slate-900 uppercase tracking-wide">Información Médica</h4>

              {Array.isArray(paciente.alergias) && paciente.alergias.length > 0 && (
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-8 w-8 rounded-lg bg-amber-100 flex items-center justify-center">
                      <AlertCircle className="h-4 w-4 text-amber-600" />
                    </div>
                    <div className="text-xs text-amber-600 font-medium">ALERGIAS</div>
                  </div>
                  <div className="space-y-1">
                    {paciente.alergias.map((alergia, index) => (
                      <div
                        key={index}
                        className="inline-flex items-center gap-1 bg-amber-100 text-amber-800 text-xs font-medium px-2 py-1 rounded-full mr-1"
                      >
                        <Shield className="h-3 w-3" />
                        {alergia}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {paciente.contactoEmergencia && (
                <div className="p-3 bg-red-50 rounded-xl border border-red-200">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="h-8 w-8 rounded-lg bg-red-100 flex items-center justify-center">
                      <Heart className="h-4 w-4 text-red-600" />
                    </div>
                    <div className="text-xs text-red-600 font-medium">CONTACTO DE EMERGENCIA</div>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <div className="text-xs text-red-500 font-medium">Nombre</div>
                      <div className="text-sm font-semibold text-red-900">
                        {paciente.contactoEmergencia.nombre}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-red-500 font-medium">Teléfono</div>
                      <div className="text-sm font-semibold text-red-900">
                        {paciente.contactoEmergencia.telefono}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-red-500 font-medium">Relación</div>
                      <div className="text-sm font-semibold text-red-900">
                        {paciente.contactoEmergencia.relacion}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

{/* Código QR */}
<div className="flex flex-col items-center gap-4 text-center">
  <h4 className="text-sm font-semibold uppercase tracking-wide text-slate-900">
  </h4>
  
  <QRDisplayHistoria paciente={paciente} />
  
  <button
    onClick={descargarQR}
    className="inline-flex items-center gap-2 rounded-xl bg-slate-600 px-3 py-2 text-sm font-medium text-white hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-500"
  >
    <Download className="h-4 w-4" />
    Descargar
  </button>
</div>
          </div>
        </div>
      </div>      
    </div>
  );
}

export default function LineaDeTiempoPaciente() {
  const navigate = useNavigate();

  // Estados del componente
  const [valorBusqueda, setValorBusqueda] = useState("");
  const [pacienteSeleccionado, setPacienteSeleccionado] = useState<PacienteSugerencia | null>(null);
  const [data, setData] = useState<LineaTiempoResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedEvento, setSelectedEvento] = useState<Evento | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [sugerencias, setSugerencias] = useState<PacienteSugerencia[]>([]);
  const [historial, setHistorial] = useState<PacienteSugerencia[]>([]);

  // ✅ BUSCAR PACIENTES EN TIEMPO REAL (con manejo UNAUTHORIZED)
  useEffect(() => {
    let timeoutId: ReturnType<typeof setTimeout> | undefined;

    // No buscar si ya hay un paciente seleccionado
    if (pacienteSeleccionado || valorBusqueda.length < 2) {
      setSugerencias([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    timeoutId = setTimeout(async () => {
      try {
        const resultados = await buscarPacientesAPI(valorBusqueda);
        setSugerencias(resultados);
      } catch (err: any) {
        if (err?.message === "UNAUTHORIZED") {
          navigate("/login");
          return;
        }
        console.error("Error en búsqueda:", err);
        setSugerencias([]);
      } finally {
        setLoading(false);
      }
    }, 300);

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [valorBusqueda, navigate, pacienteSeleccionado]);


  // ✅ CARGAR LÍNEA DE TIEMPO CUANDO SE SELECCIONA PACIENTE
  useEffect(() => {
    if (pacienteSeleccionado) {
      cargarLineaTiempo(pacienteSeleccionado.id);
    } else {
      // Limpia los datos si no hay paciente seleccionado
      setData(null);
    }
  }, [pacienteSeleccionado]);

  const cargarLineaTiempo = async (pacienteId: string) => {
    setLoading(true);
    setError(null);
    try {
      const resultado = await obtenerLineaTiempoAPI(pacienteId);
      if (resultado) {
        setData(resultado);
      } else {
        setError('No se pudo cargar la información del paciente');
      }
    } catch (err: any) {
      if (err?.message === "UNAUTHORIZED") {
        navigate("/login");
        return;
      }
      console.error('Error cargando línea de tiempo:', err);
      setError('Error al cargar la información del paciente');
    } finally {
      setLoading(false);
    }
  };

  const handleCardClick = (ev: Evento) => { 
    setSelectedEvento(ev); 
    setIsModalOpen(true); 
  };
  
  const closeModal = () => { 
    setIsModalOpen(false); 
    setSelectedEvento(null); 
  };

  const agregarAHistorial = (paciente: PacienteSugerencia) => {
    const nuevoHistorial = [paciente, ...historial.filter(p => p.id !== paciente.id)].slice(0, 5);
    setHistorial(nuevoHistorial);
    try {
      localStorage.setItem('historial-pacientes', JSON.stringify(nuevoHistorial));
    } catch (error) {
      console.warn('No se pudo guardar el historial en localStorage:', error);
    }
  };

  const limpiarHistorial = () => { 
    setHistorial([]); 
    try {
      localStorage.removeItem('historial-pacientes');
    } catch (error) {
      console.warn('No se pudo limpiar el historial de localStorage:', error);
    }
  };

  const handleSeleccionarPaciente = (paciente: PacienteSugerencia) => {
    setValorBusqueda(paciente.nombre); // Opcional: mantiene el nombre en el input de fondo
    setPacienteSeleccionado(paciente);
    agregarAHistorial(paciente);
    setSugerencias([]);
  };

  // ✅ NUEVA FUNCIÓN PARA LIMPIAR LA SELECCIÓN
  const handleLimpiarSeleccion = () => {
    setPacienteSeleccionado(null);
    setValorBusqueda("");
    setData(null);
    setError(null);
  };

  // ✅ CARGAR HISTORIAL DESDE LOCALSTORAGE AL INICIO
  useEffect(() => {
    try {
      const historialGuardado = localStorage.getItem('historial-pacientes');
      if (historialGuardado) {
        setHistorial(JSON.parse(historialGuardado));
      }
    } catch (error) {
      console.warn('Error cargando historial desde localStorage:', error);
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-6xl px-4 py-8">
        <div className="mb-8">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold mb-2">Historia Clínica</h1>
              <p className="text-lg text-slate-600">
                Busca y visualiza la información completa de cualquier paciente
              </p>
            </div>
            <div className="flex items-center gap-3">

            </div>
          </div>
        </div>

        <div className="mb-8">
          {/* RENDERIZADO CONDICIONAL: BUSCADOR O RESUMEN */}
          {!pacienteSeleccionado ? (
            <BusquedaPaciente 
              valorBusqueda={valorBusqueda} 
              onCambioBusqueda={setValorBusqueda} 
              sugerencias={sugerencias} 
              onSeleccionarSugerencia={handleSeleccionarPaciente} 
              historial={historial} 
              onSeleccionarHistorial={handleSeleccionarPaciente} 
              onLimpiarHistorial={limpiarHistorial} 
              loading={loading} 
            />
          ) : (
            <PacienteSeleccionadoResumen 
              paciente={pacienteSeleccionado}
              onLimpiar={handleLimpiarSeleccion}
            />
          )}
        </div>
        
        {error && (
          <div className="mb-6 rounded-xl border border-red-200 bg-red-50 p-4">
            <div className="flex items-center gap-3">
              <AlertCircle className="h-5 w-5 text-red-600" />
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        )}
        
        {!data && !loading && !pacienteSeleccionado && valorBusqueda.length > 0 && sugerencias.length === 0 && (
          <div className="rounded-xl border-2 border-dashed border-slate-200 p-8 text-center">
            <Users className="mx-auto h-12 w-12 text-slate-300 mb-4" />
            <h3 className="text-xl font-medium mb-2">Sin resultados</h3>
            <p className="text-slate-500">No se encontraron pacientes con "{valorBusqueda}".</p>
          </div>
        )}

        {loading && !data && (
          <div className="rounded-xl border border-slate-200 bg-white p-8 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-slate-600">Cargando información del paciente...</p>
          </div>
        )}

        {data && pacienteSeleccionado && (
          <div className="space-y-8">
            <VisualizacionPaciente paciente={data.paciente!} />
            
            {/* Línea de tiempo */}
            <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
              <div className="bg-slate-50 border-b border-slate-200 px-6 py-4">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center">
                    <FileText className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900">Línea de Tiempo Médica</h3>
                    <p className="text-sm text-slate-700">Historial completo de eventos médicos</p>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                {data.eventos.length > 0 ? (
                  <>
                    <ol className="relative ml-4 border-s border-slate-200">
                      {data.eventos.map((ev) => (
                        <li key={ev.id} className="ms-6 py-4">
                          <span className="absolute -start-3 mt-2 flex h-6 w-6 items-center justify-center rounded-full bg-white ring-2 ring-slate-200">
                            <span className="h-3 w-3 rounded-full bg-sky-500"></span>
                          </span>
                          <div 
                            role="button" 
                            tabIndex={0} 
                            onClick={() => handleCardClick(ev)} 
                            onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && handleCardClick(ev)} 
                            className="rounded-2xl border bg-slate-50 p-4 shadow-sm cursor-pointer transition-all hover:shadow-md hover:border-sky-200 hover:bg-white"
                          >
                            <div className="flex items-center justify-between mb-3">
                              <div className={classNames("inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium ring-1", badgeColorByTipo(ev.tipo))}>
                                {iconByTipo(ev.tipo)}
                                <span>{ev.tipo}</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-slate-600 mb-3">
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4" />
                                {formatFecha(ev.fecha)}
                              </div>
                            </div>
                            {ev.resumen && <p className="text-sm leading-6 mb-3">{ev.resumen}</p>}
                            <div className="flex items-center justify-between">
                              <div className="text-xs text-slate-500">Clic para ver detalles</div>
                              <div className="text-slate-400">→</div>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ol>
                    <div className="mt-6 flex items-center justify-between text-sm text-slate-500">
                      <span>{data.eventos.length} evento(s) en total</span>
                      <span>Ordenado por fecha (más reciente primero)</span>
                      <button
                        type="button"
                        onClick={() => navigate("/", { replace: true })}
                        className="inline-flex items-center gap-2 rounded-xl bg-slate-700 px-3 py-1.5 text-sm font-medium text-white shadow-sm hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-500"
                      >
                        Página principal
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-12">
                    <FileText className="mx-auto h-12 w-12 text-slate-300 mb-4" />
                    <h4 className="text-lg font-medium mb-2">Sin eventos médicos</h4>
                    <p className="text-slate-400">Este paciente aún no tiene eventos en su historial.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
      <EventoModal 
        evento={selectedEvento} 
        paciente={data?.paciente || null} 
        isOpen={isModalOpen} 
        onClose={closeModal} 
      />
    </div>
  );
}