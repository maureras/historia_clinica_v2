// src/pages/Dashboard.tsx
import React from "react";
import { UserPlus, Stethoscope, FileText, Activity } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";

type Action = {
  label: string;
  description: string;
  icon: React.ReactNode;
  gradient: string;     // gradiente del header y barra inferior
  ringFocus: string;    // color del focus ring
  hoverShadow: string;  // sombra coloreada al hover
  hoverBorder: string;  // borde coloreado al hover
  onClick: () => void;
  roles: string[];      // roles permitidos para esta acción
};

export default function Dashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const go = (path: string) => navigate(path);

  const fullName = React.useMemo(
    () => [user?.nombres, user?.apellidos].filter(Boolean).join(" "),
    [user]
  );

  const actions: Action[] = [
    {
      label: "Nuevo Paciente",
      description: "Registra datos iniciales y crea la ficha del paciente.",
      icon: <UserPlus className="h-5 w-5 text-white" />,
      gradient: "from-blue-500 to-blue-600",
      ringFocus: "focus:ring-blue-500",
      hoverShadow: "hover:shadow-blue-200/70",
      hoverBorder: "hover:border-blue-300",
      onClick: () => go("/paciente"),
      roles: ["ADMIN", "MEDICO", "ENFERMERA", "ADMINISTRATIVO"],
    },
    {
      label: "Nueva Consulta",
      description: "Inicia una consulta y registra evolución clínica.",
      icon: <Stethoscope className="h-5 w-5 text-white" />,
      gradient: "from-emerald-500 to-emerald-600",
      ringFocus: "focus:ring-emerald-500",
      hoverShadow: "hover:shadow-emerald-200/70",
      hoverBorder: "hover:border-emerald-300",
      onClick: () => go("/consulta"),
      roles: ["ADMIN", "MEDICO" ],
    },
    {
      label: "Historias Clínicas",
      description: "Busca, revisa y administra historias existentes.",
      icon: <FileText className="h-5 w-5 text-white" />,
      gradient: "from-amber-500 to-amber-600",
      ringFocus: "focus:ring-amber-500",
      hoverShadow: "hover:shadow-amber-200/70",
      hoverBorder: "hover:border-amber-300",
      onClick: () => go("/historia"),
      roles: ["ADMIN", "MEDICO", "ENFERMERA", "ADMINISTRATIVO"],
    },
  ];
  // Filtrar acciones según el rol del usuario
  const allowedActions = actions.filter(
    (action) => user && action.roles.includes(user.rol)
  );

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Buenos días";
    if (hour < 18) return "Buenas tardes";
    return "Buenas noches";
  };

  const getRoleDescription = () => {
    switch (user?.rol) {
      case "ADMIN":
        return "Panel de administración - Control total del sistema";
      case "MEDICO":
        return `Área médica${user.especialidad ? ` - ${user.especialidad}` : ""}`;
      case "ENFERMERA":
        return "Área de enfermería - Cuidado y atención";
      case "ADMINISTRATIVO":
        return "Área administrativa - Gestión y soporte";
      default:
        return "Sistema de gestión clínica";
    }
  };

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-7xl px-4 py-8">
        {/* Encabezado */}
        <div className="mb-8">

          <h1 className="mt-2 text-4xl font-bold text-slate-900">
            {getGreeting()}
            {fullName && `, ${fullName}`}
          </h1>
          <p className="text-lg text-slate-600 mt-2">{getRoleDescription()}</p>

          {/* Estadísticas rápidas */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl p-4 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xl font-semibold">{user?.rol ?? "—"}</p>
                  {fullName && (
                    <p className="text-sm font-medium mt-1">{fullName}</p>
                  )}
                  {user?.email && (
                    <p className="text-sm text-blue-100/90">{user.email}</p>
                  )}
                </div>
                <Activity className="h-8 w-8 text-blue-200" />
              </div>
            </div>
          </div>
        </div>

        {/* Cards */}
        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-6 lg:p-8">
          <h2 className="text-xl font-semibold text-slate-900 mb-5">
            Acciones principales
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {allowedActions.map((a) => (
              <button
                key={a.label}
                onClick={a.onClick}
                className={`group relative text-left rounded-2xl border border-slate-200 bg-white shadow-sm p-5
                            transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5
                            ${a.hoverShadow} ${a.hoverBorder}
                            focus:outline-none ${a.ringFocus} focus:ring-2`}
                aria-label={a.label}
              >
                {/* Header con gradiente */}
                <div
                  className={`-mx-5 -mt-5 mb-5 px-5 py-4 border-b rounded-t-2xl bg-gradient-to-r ${a.gradient}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-white/20 flex items-center justify-center">
                      {a.icon}
                    </div>
                    <h3 className="font-semibold text-white">{a.label}</h3>
                  </div>
                </div>

                <p className="text-sm text-slate-600">{a.description}</p>

                {/* Barra inferior de acento */}
                <div className="mt-5">
                  <div
                    className={`h-1 rounded-full bg-gradient-to-r ${a.gradient} transition-transform duration-200 group-hover:scale-[1.02]`}
                  />
                </div>
              </button>
            ))}
          </div>

          {/* Mensaje si no hay acciones disponibles */}
          {allowedActions.length === 0 && (
            <div className="text-center py-12">
              <Activity className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">
                Sin acciones disponibles
              </h3>
              <p className="text-slate-600">
                Tu rol actual no tiene permisos para las acciones del dashboard.
                Contacta al administrador si necesitas acceso adicional.
              </p>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
