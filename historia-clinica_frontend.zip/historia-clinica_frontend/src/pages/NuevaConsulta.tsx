import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import {
  User, QrCode, Calendar, AlertCircle, Search, Users, Phone, Hash,
  CreditCard, Mail, MapPin, Heart, Droplets, UserCheck, Shield, Edit,
  Eye, Star, Download, Share, X, Check, Stethoscope, ClipboardList,
  FileText, Pill, Activity, TestTube, Upload, FileCheck, Loader2
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { authService } from "@/services/authService";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";
const SERVER_URL = import.meta.env.VITE_SERVER_URL ?? API_URL.replace(':4000', ':5173'); // URL del servidor web

// ===================== Helpers de autenticación =====================
const getToken = () => localStorage.getItem("token");

const authHeaders = () => {
  const token = getToken();
  return {
    Accept: "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

// Úsalo cuando quieras enviar JSON
const authJsonHeaders = () => ({
  "Content-Type": "application/json",
  ...authHeaders(),
});

// Wrappers con authService (envía Bearer desde clinica_token)
const withAuth = (opts: RequestInit = {}): RequestInit => ({
  credentials: "include",
  ...opts,
  headers: {
    ...(opts.headers || {}),
    ...authService.authHeaders(),       // GET/DELETE/FormData
  },
});

const withAuthJson = (opts: RequestInit = {}): RequestInit => ({
  credentials: "include",
  ...opts,
  headers: {
    ...(opts.headers || {}),
    ...authService.authJsonHeaders(),   // JSON: añade Content-Type
  },
});

// ===================== Tipos/Interfaces =====================
export interface PacienteData {
  id: number;
  nombres: string;
  apellidos: string;
  numeroIdentificacion: string;
  fechaNacimiento?: string;
  sexo?: string;
  email?: string;
  celular?: string;
  telefono?: string;
  direccion?: string;
  grupoSanguineo?: string;
  alergias?: string[];
  contactoEmergencia?: {
    nombre: string;
    telefono: string;
    relacion: string;
  };
  qrCode?: string;
  qrData?: string;
  foto?: string;
  consultasRecientes?: any[];
}

interface ConsultaData {
  pacienteId: number;
  padecimientoActual: {
    motivo?: string;
    tiempo?: string;
    descripcion?: string;
    intensidad?: string;
  } | null;
  signosVitales: {
    frecuenciaCardiaca?: number;
    frecuenciaRespiratoria?: number;
    presionArterial?: string;
    temperatura?: number;
    saturacion?: number;
    peso?: number;
    talla?: number;
  } | null;
  exploracionFisica: {
    aspectoGeneral?: string;
    sistemaCardiovascular?: string;
    sistemaRespiratorio?: string;
    sistemaDigestivo?: string;
    sistemaNeurologico?: string;
    sistemaMusculoesqueletico?: string;
    pielFaneras?: string;
    hallazgosRelevantes?: string;
    observaciones?: string;
  } | null;
  diagnostico: {
    descripcion?: string;
    impresionClinica?: string;
    codigoCIE10?: string;
  } | null;
  tratamiento: {
    prescripcionesResumen?: string;
    indicacionesGenerales?: string;
    proximaCita?: string;
  } | null;
  examenes: {
    tipo?: string;
    examenes?: string;
    indicaciones?: string;
    urgencia?: string;
  } | null;
}

// ✅ Interfaces para Laboratorio
interface ResultadoLaboratorio {
  prueba: string;
  valor: string;
  unidad?: string;
  rango?: string;
}

interface LaboratorioData {
  id: number;
  archivo: string;
  url: string;
  fecha_informe: string | null;
  resumen_hallazgos: string;
  resultados: ResultadoLaboratorio[];
  paciente?: {
    nombres: string;
    apellidos: string;
    numeroIdentificacion: string;
  };
}

// ===================== Toast =====================
const Toast: React.FC<{
  message: string;
  type: 'success' | 'error';
  onClose: () => void;
}> = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 5000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className={`fixed top-4 right-4 z-50 max-w-sm w-full transform transition-all duration-300 ${
      type === 'success'
        ? 'bg-green-600 text-white'
        : 'bg-red-600 text-white'
    } rounded-lg shadow-lg p-4`}>
      <div className="flex items-center gap-3">
        {type === 'success' ? (
          <Check className="h-5 w-5 flex-shrink-0" />
        ) : (
          <X className="h-5 w-5 flex-shrink-0" />
        )}
        <div className="flex-1">
          <p className="text-sm font-medium">{message}</p>
        </div>
        <button
          onClick={onClose}
          className="text-white/80 hover:text-white transition-colors"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

// ===================== Uploader Laboratorio =====================
const FileUploader: React.FC<{
  onFileSelect: (file: File) => void;
  uploading: boolean;
  acceptedTypes?: string;
}> = ({ onFileSelect, uploading, acceptedTypes = ".pdf,.jpg,.jpeg,.png" }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleFileSelect = (file: File) => {
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      alert('Solo se permiten archivos PDF e imágenes (JPG, PNG)');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      alert('El archivo es muy grande. Máximo 10MB permitido.');
      return;
    }

    onFileSelect(file);
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);

    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, []);

  return (
    <div className="space-y-4">
      <div
        className={`relative border-2 border-dashed rounded-xl p-6 text-center transition-all ${
          dragOver
            ? 'border-purple-500 bg-purple-50'
            : 'border-slate-300 hover:border-slate-400'
        } ${uploading ? 'opacity-50 pointer-events-none' : ''}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept={acceptedTypes}
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleFileSelect(file);
          }}
          className="hidden"
          disabled={uploading}
        />

        <div className="space-y-3">
          <div className="flex justify-center">
            {uploading ? (
              <Loader2 className="h-10 w-10 text-purple-500 animate-spin" />
            ) : (
              <Upload className="h-10 w-10 text-slate-400" />
            )}
          </div>

          <div>
            <h4 className="text-base font-medium text-slate-900">
              {uploading ? 'Procesando archivo...' : 'Subir examen de laboratorio'}
            </h4>
            <p className="text-sm text-slate-500 mt-1">
              {uploading
                ? 'Analizando el documento con IA...'
                : 'Arrastra el archivo aquí o haz clic para seleccionar'
              }
            </p>
          </div>

          {!uploading && (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-2 rounded-lg bg-purple-600 px-4 py-2 text-sm font-medium text-white hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500"
            >
              <FileText className="h-4 w-4" />
              Seleccionar archivo
            </button>
          )}
        </div>

        <div className="mt-3 text-xs text-slate-400">
          Formatos: PDF, JPG, PNG • Máximo 10MB
        </div>
      </div>
    </div>
  );
};

// ===================== Resultado Laboratorio =====================
const LaboratorioResultado: React.FC<{ laboratorio: LaboratorioData }> = ({ laboratorio }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="border border-slate-200 rounded-xl bg-white shadow-sm overflow-hidden">
      <div className="bg-green-50 border-b border-green-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-full bg-green-600 flex items-center justify-center">
              <FileCheck className="h-4 w-4 text-white" />
            </div>
            <div>
              <h4 className="font-medium text-green-900">{laboratorio.archivo}</h4>
              <div className="flex items-center gap-2 text-sm text-green-700">
                <Calendar className="h-3 w-3" />
                <span>{laboratorio.fecha_informe || 'Fecha no disponible'}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setExpanded(!expanded)}
              className="inline-flex items-center gap-1 rounded-lg bg-green-100 px-3 py-1 text-sm font-medium text-green-700 hover:bg-green-200"
            >
              <Eye className="h-3 w-3" />
              {expanded ? 'Ocultar' : 'Ver detalles'}
            </button>

            <a
              href={`${API_URL}${laboratorio.url}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 rounded-lg bg-blue-100 px-3 py-1 text-sm font-medium text-blue-700 hover:bg-blue-200"
            >
              <Download className="h-3 w-3" />
              Descargar
            </a>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="bg-slate-50 rounded-lg p-3">
          <h5 className="text-sm font-medium text-slate-900 mb-1">Resumen de hallazgos:</h5>
          <p className="text-sm text-slate-700">{laboratorio.resumen_hallazgos}</p>
        </div>
      </div>

      {expanded && (
        <div className="border-t border-slate-200 p-4">
          <h5 className="text-sm font-semibold text-slate-900 mb-3">
            Resultados detallados ({laboratorio.resultados.length} pruebas)
          </h5>

          <div className="space-y-2 max-h-64 overflow-y-auto">
            {laboratorio.resultados.map((resultado, index) => (
              <div key={index} className="grid grid-cols-4 gap-3 py-2 px-3 bg-slate-50 rounded-lg text-sm">
                <div>
                  <span className="text-xs text-slate-500 uppercase font-medium">Prueba</span>
                  <p className="text-slate-900 font-medium">{resultado.prueba}</p>
                </div>
                <div>
                  <span className="text-xs text-slate-500 uppercase font-medium">Valor</span>
                  <p className="text-slate-900">{resultado.valor}</p>
                </div>
                <div>
                  <span className="text-xs text-slate-500 uppercase font-medium">Unidad</span>
                  <p className="text-slate-700">{resultado.unidad || 'N/A'}</p>
                </div>
                <div>
                  <span className="text-xs text-slate-500 uppercase font-medium">Rango</span>
                  <p className="text-slate-700">{resultado.rango || 'N/A'}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// ===================== Módulo Laboratorio (carga/IA) =====================
const ModuloLaboratorio: React.FC<{
  pacienteId: number;
  consultaId?: number;
  onLaboratorioSubido?: (laboratorio: LaboratorioData) => void;
}> = ({ pacienteId, consultaId, onLaboratorioSubido }) => {
  const [uploading, setUploading] = useState(false);
  const [laboratorios, setLaboratorios] = useState<LaboratorioData[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleFileUpload = async (file: File) => {
    setUploading(true);
    setError(null);
    setSuccess(null);

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('paciente_id', pacienteId.toString());
      if (consultaId) {
        formData.append('consulta_id', consultaId.toString());
      }

      const response = await fetch(
        `${API_URL}/api/laboratorio/upload`,
        withAuth({ method: 'POST', body: formData })
      );

      if (response.status === 401) {
        setError('Sesión expirada. Inicia sesión.');
        return;
      }

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || result.error || 'Error al subir el archivo');
      }

      const nuevoLaboratorio = result.data;
      setLaboratorios(prev => [nuevoLaboratorio, ...prev]);
      setSuccess(`✅ ${file.name} procesado exitosamente`);

      if (onLaboratorioSubido) onLaboratorioSubido(nuevoLaboratorio);

    } catch (err: any) {
      console.error('❌ Error al subir laboratorio:', err);
      setError(err.message || 'Error al procesar el archivo de laboratorio');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-4">
      {error && (
        <div className="flex items-center gap-3 p-3 bg-red-50 border border-red-200 rounded-lg text-red-800">
          <AlertCircle className="h-4 w-4 flex-shrink-0" />
          <p className="text-sm flex-1">{error}</p>
          <button onClick={() => setError(null)} className="text-red-600 hover:text-red-800">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {success && (
        <div className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-lg text-green-800">
          <Check className="h-4 w-4 flex-shrink-0" />
          <p className="text-sm flex-1">{success}</p>
          <button onClick={() => setSuccess(null)} className="text-green-600 hover:text-green-800">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      <FileUploader onFileSelect={handleFileUpload} uploading={uploading} />

      {laboratorios.length > 0 && (
        <div className="space-y-3">
          <h5 className="text-base font-semibold text-slate-900">
            Exámenes procesados ({laboratorios.length})
          </h5>

          <div className="space-y-3 max-h-96 overflow-y-auto">
            {laboratorios.map((laboratorio) => (
              <LaboratorioResultado key={laboratorio.id} laboratorio={laboratorio} />
            ))}
          </div>
        </div>
      )}

      <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
        <div className="flex items-start gap-3">
          <TestTube className="h-4 w-4 text-purple-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-purple-800">
            <h6 className="font-medium mb-1">Análisis inteligente</h6>
            <p className="text-purple-700 text-xs">
              Los archivos se procesan automáticamente con IA para extraer resultados y hallazgos.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// ===================== Búsqueda/Selección de Paciente =====================
const PacienteForm: React.FC<{ onChange: (paciente: PacienteData | null) => void; pacienteInicial?: PacienteData | null }> = ({ onChange, pacienteInicial = null }) => {
  const navigate = useNavigate();

  const [query, setQuery] = useState("");
  const [pacienteSeleccionado, setPacienteSeleccionado] = useState<PacienteData | null>(pacienteInicial);
  const [showDropdown, setShowDropdown] = useState(false);
  const [sugerencias, setSugerencias] = useState<PacienteData[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const buscarPacientes = async () => {
      if (query.length >= 2) {
        setLoading(true);
        setError(null);

        try {
          const response = await fetch(
            `${API_URL}/api/pacientes/buscar-consultas?q=${encodeURIComponent(query)}`,
            withAuth({ method: 'GET' })
          );

          if (response.status === 401) {
            setError('Sesión expirada. Inicia sesión nuevamente.');
            navigate('/login');
            return;
          }

          if (!response.ok) {
            throw new Error(`Error HTTP ${response.status}`);
          }

          const resultados = await response.json();
          setSugerencias(resultados);
          setShowDropdown(true);
        } catch (error) {
          console.error('Error al buscar pacientes:', error);
          setError('Error al buscar pacientes');
          setSugerencias([]);
        } finally {
          setLoading(false);
        }
      } else {
        setSugerencias([]);
        setShowDropdown(false);
      }
    };

    const debounceTimer = setTimeout(buscarPacientes, 300);
    return () => clearTimeout(debounceTimer);
  }, [query, navigate]);

  const seleccionarPaciente = async (paciente: PacienteData) => {
    try {
      const response = await fetch(
        `${API_URL}/api/pacientes/completo/${paciente.id}`,
        withAuth({ method: 'GET' })
      );

      if (response.status === 401) {
        setError('Sesión expirada. Inicia sesión nuevamente.');
        navigate('/login');
        return;
      }

      if (!response.ok) {
        throw new Error(`Error al obtener datos completos del paciente`);
      }

      const pacienteCompleto = await response.json();

      setPacienteSeleccionado(pacienteCompleto);
      setQuery(`${pacienteCompleto.nombres} ${pacienteCompleto.apellidos} (${pacienteCompleto.numeroIdentificacion})`);
      setShowDropdown(false);
      onChange(pacienteCompleto);
    } catch (error) {
      console.error('Error al obtener paciente completo:', error);
      setError('Error al cargar datos del paciente');
    }
  };

  const limpiarSeleccion = () => {
    setQuery("");
    setPacienteSeleccionado(null);
    setShowDropdown(false);
    setError(null);
    onChange(null);
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-visible">
      {/* Header */}
      <div className="bg-blue-50 border-b border-blue-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center">
              <Users className="h-4 w-4 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-blue-900">Buscar Paciente</h3>
              <p className="text-sm text-blue-700">
                Busque y seleccione el paciente para la consulta
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6">
        {!pacienteSeleccionado ? (
          <div className="space-y-4">
            <div className="relative">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-slate-400" />
                </div>
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Escriba el nombre o cédula del paciente..."
                  className="block w-full pl-10 pr-10 py-3 border border-slate-300 rounded-xl shadow-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                />
                {loading && (
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                  </div>
                )}
              </div>

              {error && (
                <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                  {error}
                </div>
              )}

              {showDropdown && sugerencias.length > 0 && (
                <div className="absolute z-50 mt-1 w-full bg-white shadow-2xl max-h-80 rounded-xl py-1 overflow-auto border border-slate-200">
                  {sugerencias.map((paciente) => (
                    <div
                      key={paciente.id}
                      className="cursor-pointer select-none py-4 px-4 hover:bg-blue-50 border-l-4 border-l-transparent hover:border-l-blue-500 transition-all"
                      onClick={() => seleccionarPaciente(paciente)}
                    >
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 relative">
                          <div className="h-12 w-12 rounded-xl bg-slate-100 flex items-center justify-center">
                            {paciente.foto ? (
                              <img src={paciente.foto} alt="Foto" className="w-full h-full rounded-xl object-cover" />
                            ) : (
                              <User className="h-6 w-6 text-slate-600" />
                            )}
                          </div>
                          <div className="absolute -top-1 -right-1 h-6 w-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">
                            {paciente.id}
                          </div>
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-base text-slate-900">
                            {paciente.nombres} {paciente.apellidos}
                          </h4>
                          <div className="grid grid-cols-2 gap-2 mt-2">
                            <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 rounded-lg">
                              <CreditCard className="h-3 w-3 text-green-600" />
                              <span className="text-xs font-medium text-green-700">CI:</span>
                              <span className="text-sm font-bold text-green-900 font-mono">{paciente.numeroIdentificacion}</span>
                            </div>
                            {paciente.celular && (
                              <div className="flex items-center gap-1 text-xs text-slate-500">
                                <Phone className="h-3 w-3" />
                                <span>{paciente.celular}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {showDropdown && sugerencias.length === 0 && !loading && query.length >= 2 && (
                <div className="absolute z-50 mt-1 w-full bg-white shadow-lg rounded-xl py-4 px-4 border border-slate-200">
                  <div className="text-center text-slate-500">
                    <Search className="h-8 w-8 mx-auto mb-2 text-slate-400" />
                    <p>No se encontraron pacientes para "{query}"</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          
<div className="p-4 bg-green-50 border border-green-200 rounded-xl">
    <div className="flex items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <div className="h-10 w-10 rounded-full bg-green-600 flex items-center justify-center">
          <UserCheck className="h-5 w-5 text-white" />
        </div>
        <div>
          <div className="text-xs font-medium text-green-700">Paciente seleccionado</div>
          <div className="font-semibold text-green-900">
            {pacienteSeleccionado.nombres} {pacienteSeleccionado.apellidos}
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-green-700">
            <span className="inline-flex items-center gap-1">
              <Hash className="h-3 w-3" />
              ID: {pacienteSeleccionado.id}
            </span>
            {pacienteSeleccionado.numeroIdentificacion && (
              <span className="inline-flex items-center gap-1">
                <CreditCard className="h-3 w-3" />
                CI: <span className="font-mono">{pacienteSeleccionado.numeroIdentificacion}</span>
              </span>
            )}
          </div>
        </div>
      </div>

      <button
        onClick={limpiarSeleccion}
        className="inline-flex items-center gap-2 rounded-lg border border-green-200 bg-white/70 px-3 py-2 text-sm font-medium text-green-700 hover:bg-white hover:text-green-900 transition-colors"
        title="Quitar paciente seleccionado"
      >
        <X className="h-4 w-4" />
        Quitar
      </button>
    </div>
  </div>
)}
      </div>
    </div>
  );
};

// ===================== QR con prefetch + auth =====================
const QRDisplay: React.FC<{ paciente: PacienteData; onReload: () => void }> = ({ paciente }) => {
  const [src, setSrc] = useState<string | null>(null);
  const [qrError, setQrError] = useState(false);

  const datosQR = useMemo(
    () =>
      paciente.qrData ||
      JSON.stringify({
        id: paciente.id,
        nombre: `${paciente.nombres} ${paciente.apellidos}`.trim(),
        numeroIdentificacion: paciente.numeroIdentificacion,
      }),
    [paciente]
  );

  const fallbackSrc = useMemo(
    () =>
      `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(
        datosQR
      )}`,
    [datosQR]
  );

  useEffect(() => {
    let revoke: string | null = null;
    setQrError(false);

    const load = async () => {
      const raw = paciente.qrCode;
      if (!raw) {
        setSrc(fallbackSrc);
        return;
      }

      // Normalizar URL
      const abs = /^(data:|https?:\/\/)/i.test(raw)
        ? raw
        : `${API_URL.replace(/\/+$/, "")}/${String(raw).replace(/^\/+/, "")}`;

      if (abs.startsWith("data:")) {
        setSrc(abs);
        return;
      }

      try {
        const resp = await fetch(
          abs,
          withAuth({ method: "GET", cache: "no-store", mode: "cors" })
        );
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const blob = await resp.blob();
        const url = URL.createObjectURL(blob);
        revoke = url;
        setSrc(url);
      } catch (e) {
        console.warn("No se pudo cargar QR protegido, usando fallback:", e);
        setQrError(true);
        setSrc(fallbackSrc);
      }
    };

    load();
    return () => {
      if (revoke) URL.revokeObjectURL(revoke);
    };
  }, [paciente.qrCode, fallbackSrc]);

  const descargarQR = () => {
    const a = document.createElement("a");
    a.href = src || fallbackSrc;
    a.download = `QR_${(`${paciente.nombres} ${paciente.apellidos}`).trim().replace(/\s+/g, "_")}.png`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  return (
    <div className="text-center">
      <div className="inline-flex items-center gap-2 text-emerald-700 font-medium mb-3">
        <QrCode className="w-4 h-4" />
        <span className="text-sm">Código QR</span>
      </div>

      {src ? (
        <div className="space-y-2">
          <div className="flex justify-center">
            <div className="p-3 bg-white rounded-xl border-2 border-emerald-200 shadow-sm">
              <img
                src={src}
                alt="Código QR del paciente"
                className="w-32 h-32"
                onError={() => {
                  setQrError(true);
                  setSrc(fallbackSrc);
                }}
              />
            </div>
          </div>



          <div className="mt-3">
            <button
              onClick={descargarQR}
              className="inline-flex items-center gap-2 rounded-xl bg-slate-600 px-3 py-2 text-sm font-medium text-white hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-500"
            >
              <Download className="h-4 w-4" />
              Descargar
            </button>
          </div>

          {qrError && (
            <div className="text-[11px] text-amber-600">Mostrando QR alternativo</div>
          )}
        </div>
      ) : (
        <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
          <QrCode className="w-8 h-8 text-slate-400 mx-auto mb-2" />
          <p className="text-sm text-slate-500">{qrError ? "Error cargando QR" : "Cargando..."}</p>
        </div>
      )}
    </div>
  );
};

// ===================== Visualización completa del paciente =====================
const VisualizacionCompletaPaciente: React.FC<{ paciente: PacienteData; onReload: () => void }> = ({ paciente, onReload }) => {
  const formatearFecha = (fechaStr?: string) => {
    if (!fechaStr) return null;
    try {
      return new Date(fechaStr).toLocaleDateString('es-ES', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch {
      return null;
    }
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
      {/* Header con gradiente */}
      <div className="bg-gradient-to-r from-sky-50 to-blue-50 border-b border-sky-200 px-6 py-6">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center">
              {paciente.foto ? (
                <img src={paciente.foto} alt="Foto del paciente" className="w-full h-full rounded-2xl object-cover" />
              ) : (
                <User className="h-8 w-8 text-white" />
              )}
            </div>
            <div className="absolute -top-1 -right-1 h-6 w-6 bg-green-500 text-white rounded-full flex items-center justify-center text-xs font-bold">
              <UserCheck className="h-3 w-3" />
            </div>
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h2 className="text-2xl font-bold text-sky-900">{paciente.nombres} {paciente.apellidos}</h2>
              <div className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-medium bg-sky-100 text-sky-700 ring-1 ring-sky-200">
                <Star className="h-3 w-3" />
                <span>En Consulta</span>
              </div>
            </div>
            <div className="flex items-center gap-4 text-sm text-sky-700">
              <div className="flex items-center gap-2">
                <Hash className="h-4 w-4" />
                <span className="font-medium">ID: {paciente.id}</span>
              </div>
              <div className="flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                <span className="font-mono">{paciente.numeroIdentificacion}</span>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <button className="inline-flex items-center gap-2 rounded-xl bg-white/80 px-3 py-2 text-sm font-medium text-sky-700 hover:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500">
              <Edit className="h-4 w-4" />
              Editar
            </button>
            <button className="inline-flex items-center gap-2 rounded-xl bg-sky-600 px-3 py-2 text-sm font-medium text-white hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500">
              <Eye className="h-4 w-4" />
              Ver Historial
            </button>
          </div>
        </div>
      </div>

      {/* Información organizada */}
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Información personal */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold text-slate-900 uppercase tracking-wide">Información Personal</h4>

            {paciente.fechaNacimiento && (
              <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                <div className="h-10 w-10 rounded-lg bg-slate-100 flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-slate-600" />
                </div>
                <div>
                  <div className="text-xs text-slate-500 font-medium">Fecha de Nacimiento</div>
                  <div className="text-sm font-semibold text-slate-900">{formatearFecha(paciente.fechaNacimiento)}</div>
                </div>
              </div>
            )}

            {paciente.sexo && (
              <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-xl">
                <div className="h-10 w-10 rounded-lg bg-purple-100 flex items-center justify-center">
                  <User className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <div className="text-xs text-purple-500 font-medium">Sexo</div>
                  <div className="text-sm font-semibold text-purple-900">{paciente.sexo}</div>
                </div>
              </div>
            )}

            {paciente.grupoSanguineo && (
              <div className="flex items-center gap-3 p-3 bg-red-50 rounded-xl">
                <div className="h-10 w-10 rounded-lg bg-red-100 flex items-center justify-center">
                  <Droplets className="h-5 w-5 text-red-600" />
                </div>
                <div>
                  <div className="text-xs text-red-500 font-medium">Grupo Sanguíneo</div>
                  <div className="text-sm font-semibold text-red-900">{paciente.grupoSanguineo}</div>
                </div>
              </div>
            )}
          </div>

          {/* Información de contacto */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold text-slate-900 uppercase tracking-wide">Contacto</h4>

            {paciente.celular && (
              <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl">
                <div className="h-10 w-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Phone className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <div className="text-xs text-blue-500 font-medium">Teléfono</div>
                  <div className="text-sm font-semibold text-blue-900">{paciente.celular}</div>
                </div>
              </div>
            )}

            {paciente.email && (
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-xl">
                <div className="h-10 w-10 rounded-lg bg-green-100 flex items-center justify-center">
                  <Mail className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <div className="text-xs text-green-500 font-medium">Email</div>
                  <div className="text-sm font-semibold text-green-900">{paciente.email}</div>
                </div>
              </div>
            )}

            {paciente.direccion && (
              <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-xl">
                <div className="h-10 w-10 rounded-lg bg-purple-100 flex items-center justify-center">
                  <MapPin className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <div className="text-xs text-purple-500 font-medium">Dirección</div>
                  <div className="text-sm font-semibold text-purple-900">{paciente.direccion}</div>
                </div>
              </div>
            )}
          </div>

          {/* Información médica crítica */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold text-slate-900 uppercase tracking-wide">Información Médica</h4>

            {paciente.alergias && paciente.alergias.length > 0 && (
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
                <div className="flex items-center gap-2 mb-2">
                  <div className="h-8 w-8 rounded-lg bg-amber-100 flex items-center justify-center">
                    <AlertCircle className="h-4 w-4 text-amber-600" />
                  </div>
                  <div className="text-xs text-amber-600 font-medium">ALERGIAS</div>
                </div>
                <div className="space-y-1">
                  {paciente.alergias.map((alergia, index) => (
                    <div key={index} className="inline-flex items-center gap-1 bg-amber-100 text-amber-800 text-xs font-medium px-2 py-1 rounded-full mr-1">
                      <Shield className="h-3 w-3" />
                      {alergia}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {paciente.contactoEmergencia && (
              <div className="p-3 bg-red-50 rounded-xl border border-red-200">
                <div className="flex items-center gap-2 mb-3">
                  <div className="h-8 w-8 rounded-lg bg-red-100 flex items-center justify-center">
                    <Heart className="h-4 w-4 text-red-600" />
                  </div>
                  <div className="text-xs text-red-600 font-medium">CONTACTO DE EMERGENCIA</div>
                </div>
                <div className="space-y-2">
                  <div>
                    <div className="text-xs text-red-500 font-medium">Nombre</div>
                    <div className="text-sm font-semibold text-red-900">{paciente.contactoEmergencia.nombre}</div>
                  </div>
                  <div>
                    <div className="text-xs text-red-500 font-medium">Teléfono</div>
                    <div className="text-sm font-semibold text-red-900">{paciente.contactoEmergencia.telefono}</div>
                  </div>
                  <div>
                    <div className="text-xs text-red-500 font-medium">Relación</div>
                    <div className="text-sm font-semibold text-red-900">{paciente.contactoEmergencia.relacion}</div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Código QR */}
          <div className="flex flex-col items-center gap-4 text-center">
            <h4 className="text-sm font-semibold uppercase tracking-wide text-slate-900">Código QR</h4>
            <QRDisplay paciente={paciente} onReload={onReload} />
          </div>

        </div>
      </div>
    </div>
  );
};

// ===================== Sección contenedora de formularios =====================
const SeccionFormulario: React.FC<{
  titulo: string;
  icono: React.ReactNode;
  color: string;
  children: React.ReactNode;
}> = ({ titulo, icono, color, children }) => {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
      <div className={`${color} border-b px-6 py-4`}>
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-full bg-white/20 flex items-center justify-center">
            {icono}
          </div>
          <div>
            <h3 className="font-semibold text-white">{titulo}</h3>
            <p className="text-sm text-white/80">Complete la información requerida</p>
          </div>
        </div>
      </div>
      <div className="p-6">
        {children}
      </div>
    </div>
  );
};

// ===================== Página principal: NuevaConsulta =====================
const NuevaConsulta: React.FC = () => {
  const navigate = useNavigate();

  const [pacienteSeleccionado, setPacienteSeleccionado] = useState<PacienteData | null>(null);
  const [data, setData] = useState<ConsultaData>({
    pacienteId: 0,
    padecimientoActual: null,
    signosVitales: null,
    exploracionFisica: null,
    diagnostico: null,
    tratamiento: null,
    examenes: null,
  });
  const [submitting, setSubmitting] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const onPatch = (patch: Partial<ConsultaData>) => setData((prev) => ({ ...prev, ...patch }));

  const handlePacienteChange = (paciente: PacienteData | null) => {
    setPacienteSeleccionado(paciente);
    if (paciente) {
      onPatch({ pacienteId: paciente.id });
    } else {
      onPatch({ pacienteId: 0 });
    }
  };

  const reloadPaciente = () => {
    // Si quieres recargar datos del paciente luego de cambios, hazlo aquí
  };

  // Guardar consulta
  const finalizar = async () => {
    if (!pacienteSeleccionado) {
      setToast({ message: "Seleccione un paciente", type: 'error' });
      return;
    }

    setSubmitting(true);
    setToast(null);

    try {
      const response = await fetch(
        `${API_URL}/api/consultas/finalizar`,
        withAuthJson({
          method: 'POST',
          body: JSON.stringify(data),
        })
      );

      if (response.status === 401) {
        setToast({ message: 'Sesión expirada. Inicia sesión.', type: 'error' });
        navigate('/login');
        return;
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || errorData.error || `Error HTTP ${response.status}`);
      }

      const resultado = await response.json();
      setToast({
        message: `¡Consulta registrada exitosamente! ID: ${resultado.data?.consultaId || 'N/A'}`,
        type: 'success'
      });

    } catch (error) {
      console.error('❌ Error al guardar consulta:', error);
      setToast({
        message: error instanceof Error ? error.message : 'Error al registrar la consulta',
        type: 'error'
      });
    } finally {
      setSubmitting(false);
    }
  };

  // Actualización de campos
  const handleInputChange = (section: keyof ConsultaData, field: string, value: any) => {
    setData(prev => {
      const currentSection = prev[section];
      const isValidObject = currentSection && typeof currentSection === 'object' && !Array.isArray(currentSection);

      return {
        ...prev,
        [section]: {
          ...(isValidObject ? currentSection : {}),
          [field]: value
        }
      };
    });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {toast && (
        <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />
      )}
      <div className="mx-auto max-w-6xl px-4 py-8">
        <div className="mb-8">
          <div className="flex items-start justify-between gap-4"></div>
            <div>
              <h1 className="text-3xl font-bold mb-2">Nueva Consulta Médica</h1>
              <p className="text-lg text-slate-600">
                Registre una nueva atención médica ambulatoria completa
              </p>
            </div>
         </div>


        <div className="space-y-8">
          {/* Selección de paciente */}
          <PacienteForm
            onChange={handlePacienteChange}
            pacienteInicial={pacienteSeleccionado}
          />

          {/* Resumen/visualización del paciente */}
          {pacienteSeleccionado && (
            <VisualizacionCompletaPaciente paciente={pacienteSeleccionado} onReload={reloadPaciente} />
          )}

          {/* Formularios solo con paciente seleccionado */}
          {pacienteSeleccionado && (
            <>
              {/* Padecimiento Actual */}
              <SeccionFormulario
                titulo="Padecimiento Actual"
                icono={<ClipboardList className="h-4 w-4 text-white" />}
                color="bg-gradient-to-r from-blue-500 to-blue-600"
              >
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Motivo de consulta</label>
                    <textarea
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      rows={3}
                      placeholder="Describa el motivo principal de la consulta..."
                      onChange={(e) => handleInputChange('padecimientoActual', 'motivo', e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Tiempo de evolución</label>
                      <input
                        type="text"
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Ej: 3 días, 1 semana..."
                        onChange={(e) => handleInputChange('padecimientoActual', 'tiempo', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Intensidad</label>
                      <select
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        onChange={(e) => handleInputChange('padecimientoActual', 'intensidad', e.target.value)}
                      >
                        <option value="">Seleccionar...</option>
                        <option value="leve">Leve</option>
                        <option value="moderado">Moderado</option>
                        <option value="severo">Severo</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Descripción detallada</label>
                    <textarea
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      rows={2}
                      placeholder="Descripción detallada del padecimiento..."
                      onChange={(e) => handleInputChange('padecimientoActual', 'descripcion', e.target.value)}
                    />
                  </div>
                </div>
              </SeccionFormulario>

              {/* Signos vitales */}
              <SeccionFormulario
                titulo="Signos Vitales"
                icono={<Activity className="h-4 w-4 text-white" />}
                color="bg-gradient-to-r from-red-500 to-red-600"
              >
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">FC (lpm)</label>
                    <input
                      type="number"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                      placeholder="80"
                      onChange={(e) => handleInputChange('signosVitales', 'frecuenciaCardiaca', parseInt(e.target.value) || null)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">FR (rpm)</label>
                    <input
                      type="number"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                      placeholder="16"
                      onChange={(e) => handleInputChange('signosVitales', 'frecuenciaRespiratoria', parseInt(e.target.value) || null)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">PA (mmHg)</label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                      placeholder="120/80"
                      onChange={(e) => handleInputChange('signosVitales', 'presionArterial', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Temp (°C)</label>
                    <input
                      type="number"
                      step="0.1"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                      placeholder="36.5"
                      onChange={(e) => handleInputChange('signosVitales', 'temperatura', parseFloat(e.target.value) || null)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Sat O2 (%)</label>
                    <input
                      type="number"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                      placeholder="98"
                      onChange={(e) => handleInputChange('signosVitales', 'saturacion', parseInt(e.target.value) || null)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Peso (kg)</label>
                    <input
                      type="number"
                      step="0.1"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                      placeholder="70"
                      onChange={(e) => handleInputChange('signosVitales', 'peso', parseFloat(e.target.value) || null)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Talla (cm)</label>
                    <input
                      type="number"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                      placeholder="170"
                      onChange={(e) => handleInputChange('signosVitales', 'talla', parseInt(e.target.value) || null)}
                    />
                  </div>
                </div>
              </SeccionFormulario>

              {/* Exploración física */}
              <SeccionFormulario
                titulo="Exploración Física"
                icono={<Stethoscope className="h-4 w-4 text-white" />}
                color="bg-gradient-to-r from-purple-500 to-purple-600"
              >
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Aspecto general</label>
                    <textarea
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      rows={2}
                      placeholder="Paciente consciente, orientado, colaborador..."
                      onChange={(e) => handleInputChange('exploracionFisica', 'aspectoGeneral', e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Sistema cardiovascular</label>
                      <textarea
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                        rows={2}
                        placeholder="Ruidos cardíacos rítmicos, sin soplos..."
                        onChange={(e) => handleInputChange('exploracionFisica', 'sistemaCardiovascular', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Sistema respiratorio</label>
                      <textarea
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                        rows={2}
                        placeholder="Murmullo vesicular conservado..."
                        onChange={(e) => handleInputChange('exploracionFisica', 'sistemaRespiratorio', e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Observaciones adicionales</label>
                    <textarea
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      rows={2}
                      placeholder="Observaciones adicionales de la exploración..."
                      onChange={(e) => handleInputChange('exploracionFisica', 'observaciones', e.target.value)}
                    />
                  </div>
                </div>
              </SeccionFormulario>

              {/* Diagnóstico */}
              <SeccionFormulario
                titulo="Diagnóstico"
                icono={<ClipboardList className="h-4 w-4 text-white" />}
                color="bg-gradient-to-r from-amber-500 to-amber-600"
              >
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Código CIE-10</label>
                      <input
                        type="text"
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                        placeholder="Ej: K59.0"
                        onChange={(e) => handleInputChange('diagnostico', 'codigoCIE10', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Diagnóstico principal</label>
                      <input
                        type="text"
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                        placeholder="Descripción del diagnóstico"
                        onChange={(e) => handleInputChange('diagnostico', 'descripcion', e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Impresión clínica</label>
                    <textarea
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                      rows={3}
                      placeholder="Descripción detallada de la impresión clínica..."
                      onChange={(e) => handleInputChange('diagnostico', 'impresionClinica', e.target.value)}
                    />
                  </div>
                </div>
              </SeccionFormulario>

              {/* Tratamiento */}
              <SeccionFormulario
                titulo="Tratamiento"
                icono={<Pill className="h-4 w-4 text-white" />}
                color="bg-gradient-to-r from-emerald-500 to-emerald-600"
              >
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Medicamentos</label>
                    <textarea
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      rows={3}
                      placeholder="Lista de medicamentos con dosis y frecuencia..."
                      onChange={(e) => handleInputChange('tratamiento', 'prescripcionesResumen', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Indicaciones generales</label>
                    <textarea
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      rows={2}
                      placeholder="Recomendaciones, dieta, reposo, etc..."
                      onChange={(e) => handleInputChange('tratamiento', 'indicacionesGenerales', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Próxima cita</label>
                    <input
                      type="date"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      onChange={(e) => handleInputChange('tratamiento', 'proximaCita', e.target.value)}
                    />
                  </div>
                </div>
              </SeccionFormulario>

              {/* Exámenes de laboratorio (solicitud) */}
              <SeccionFormulario
                titulo="Exámenes de Laboratorio"
                icono={<TestTube className="h-4 w-4 text-white" />}
                color="bg-gradient-to-r from-indigo-500 to-indigo-600"
              >
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Exámenes solicitados</label>
                    <textarea
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      rows={3}
                      placeholder="Lista de exámenes de laboratorio solicitados..."
                      onChange={(e) => handleInputChange('examenes', 'examenes', e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Tipo de examen</label>
                      <select
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        onChange={(e) => handleInputChange('examenes', 'tipo', e.target.value)}
                      >
                        <option value="">Seleccionar...</option>
                        <option value="Sangre">Sangre</option>
                        <option value="Orina">Orina</option>
                        <option value="Heces">Heces</option>
                        <option value="Radiología">Radiología</option>
                        <option value="Otro">Otro</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Urgencia</label>
                      <select
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        onChange={(e) => handleInputChange('examenes', 'urgencia', e.target.value)}
                      >
                        <option value="Normal">Normal</option>
                        <option value="Urgente">Urgente</option>
                        <option value="STAT">STAT</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Indicaciones especiales</label>
                    <textarea
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      rows={2}
                      placeholder="Ayuno, preparación especial, etc..."
                      onChange={(e) => handleInputChange('examenes', 'indicaciones', e.target.value)}
                    />
                  </div>
                </div>
              </SeccionFormulario>

              {/* Cargar resultados de laboratorio + IA */}
              <SeccionFormulario
                titulo="Cargar Resultados de Laboratorio"
                icono={<Upload className="h-4 w-4 text-white" />}
                color="bg-gradient-to-r from-purple-500 to-purple-600"
              >
                <ModuloLaboratorio
                  pacienteId={pacienteSeleccionado.id}
                  consultaId={undefined} // Se puede asignar después de guardar la consulta
                  onLaboratorioSubido={(laboratorio) => {
                    console.log('📋 Laboratorio agregado a la consulta:', laboratorio);
                  }}
                />
              </SeccionFormulario>

              {/* Botones de acción */}
              <div className="flex items-center justify-end gap-4 pt-8">
                <button
                  onClick={() => window.history.back()}
                  disabled={submitting}
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-6 py-3 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-offset-2 transition-colors disabled:opacity-50"
                >
                  <X className="h-4 w-4" />
                  Cancelar
                </button>

                <button
                  type="button"
                  onClick={() => navigate("/", { replace: true })}
                  className="inline-flex items-center gap-2 rounded-xl bg-slate-700 px-6 py-3 text-sm font-medium text-white shadow-sm hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-offset-2 transition-colors"
                >
                  Página principal
                </button>

                <button
                  onClick={finalizar}
                  disabled={submitting || toast?.type === 'success'}
                  className={`inline-flex items-center gap-2 rounded-xl border px-6 py-3 text-sm font-medium shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all disabled:opacity-50 ${
                    toast?.type === 'success'
                      ? 'border-green-200 bg-green-600 text-white hover:bg-green-700 focus:ring-green-500'
                      : 'border-sky-200 bg-gradient-to-r from-sky-500 to-sky-600 text-white hover:from-sky-600 hover:to-sky-700 focus:ring-sky-500'
                  }`}
                >
                  {submitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      Registrando consulta...
                    </>
                  ) : toast?.type === 'success' ? (
                    <>
                      <Check className="h-4 w-4" />
                      ¡Consulta registrada!
                    </>
                  ) : (
                    <>
                      <Check className="h-4 w-4" />
                      Finalizar consulta
                    </>
                  )}
                </button>
              </div>
            </>
          )}

          
        </div>
      </div>
    </div>
  );
};

export default NuevaConsulta;
