// src/pages/Login.tsx — versión con autenticación integrada (corregida)
import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Mail, Lock, Eye, EyeOff, ShieldCheck, ArrowRight, AlertCircle } from "lucide-react";
import { useAuth } from "../hooks/useAuth";

export default function Login() {
  const navigate = useNavigate();
  const { login, isAuthenticated } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // ✅ Redirección segura sin cambiar el orden de hooks
  useEffect(() => {
    if (isAuthenticated) {
      navigate("/dashboard", { replace: true });
    }
  }, [isAuthenticated, navigate]);

  // Validación de email
  const emailValid = useMemo(() => /\S+@\S+\.\S+/.test(email), [email]);

  // Puntuación de contraseña
  const pwdScore = useMemo(() => {
    let score = 0;
    if (password.length >= 8) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[a-z]/.test(password)) score++;
    if (/[0-9\W_]/.test(password)) score++;
    return score;
  }, [password]);

  const canSubmit = emailValid && password.length >= 8 && !submitting;

  // Envío del formulario
  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!canSubmit) return;
    setSubmitting(true);
    
    try {
      const result = await login(email, password, remember);
      if (result.success) {
        // Recordar correo si procede
        try {
          if (remember) {
            localStorage.setItem("rememberEmail", email);
          } else {
            localStorage.removeItem("rememberEmail");
          }
        } catch {}
        // La navegación final la maneja el useEffect al cambiar isAuthenticated
      } else {
        setError(result.error || "Credenciales no válidas. Verifica tu correo y contraseña.");
      }
    } catch (err) {
      console.error("Login error:", err);
      setError("Error de conexión con el servidor");
    } finally {
      setSubmitting(false);
    }
  }

  // Cargar email recordado
  useEffect(() => {
    try {
      const saved = localStorage.getItem("rememberEmail");
      if (saved) setEmail(saved);
    } catch {}
  }, []);

  return (
    <main className="min-h-screen bg-slate-50">
      {/* Cinta superior de acento */}
      <div className="h-1 w-full bg-gradient-to-r from-blue-600 via-cyan-600 to-emerald-600" />

      {/* Contenedor principal centrado */}
      <div className="flex min-h-[calc(100vh-4px)] items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Encabezado de la página */}
          <div className="mb-8 text-center">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 ring-8 ring-white/10">
              <ShieldCheck className="h-8 w-8 text-white" />
            </div>
            <h1 className="mt-4 text-2xl font-bold text-slate-900">Clínica Central</h1>
            <p className="text-sm text-slate-500">Acceso seguro al panel de gestión</p>
          </div>

          {/* Tarjeta del Formulario */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition-all duration-300 hover:shadow-lg md:p-8">
            {error && (
              <div className="mb-5 flex items-start gap-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-rose-700">
                <AlertCircle className="mt-0.5 h-5 w-5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium">Error de autenticación</p>
                  <p className="text-sm opacity-90">{error}</p>
                </div>
              </div>
            )}

            <form onSubmit={onSubmit} className="space-y-5" noValidate>
              {/* Campo Email */}
              <div>
                <label htmlFor="email" className="mb-2 block text-sm font-medium text-slate-700">
                  Correo electrónico
                </label>
                <div className="relative">
                  <span className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Mail className="h-5 w-5 text-slate-400" />
                  </span>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    autoComplete="email"
                    placeholder="tu@correo.com"
                    className={`w-full rounded-xl border bg-white py-3 pl-10 pr-3 text-slate-900 placeholder-slate-400 transition-all duration-200 hover:border-slate-300 ${
                      email && !emailValid
                        ? "border-rose-300 focus:border-rose-400 focus:ring-rose-400"
                        : "border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500"
                    }`}
                    aria-invalid={email ? !emailValid : undefined}
                    aria-describedby="email-help"
                    required
                  />
                </div>
 
              </div>

              {/* Campo Contraseña */}
              <div>
                <label htmlFor="password" className="mb-2 block text-sm font-medium text-slate-700">
                  Contraseña
                </label>
                <div className="relative">
                  <span className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Lock className="h-5 w-5 text-slate-400" />
                  </span>
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="current-password"
                    placeholder="••••••••"
                    className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-12 text-slate-900 placeholder-slate-400 transition-all duration-200 hover:border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500"
                    required
                    minLength={8}
                    aria-describedby="password-hint password-meter"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                    className="absolute inset-y-0 right-0 mr-2 flex items-center rounded-lg px-2 text-slate-400 transition-colors hover:text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>

                {/* Medidor de fuerza de contraseña */}
                <div id="password-meter" className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className={`h-full transition-all ${
                      pwdScore <= 1 ? "w-1/4 bg-rose-400" :
                      pwdScore === 2 ? "w-2/4 bg-amber-400" :
                      pwdScore === 3 ? "w-3/4 bg-cyan-500" :
                      pwdScore >= 4 ? "w-full bg-emerald-500" : ""
                    }`}
                  />
                </div>
              </div>

              {/* Opciones adicionales */}
              <div className="flex items-center justify-between">
                <label className="inline-flex cursor-pointer items-center gap-2">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                    checked={remember}
                    onChange={(e) => setRemember(e.target.checked)}
                  />
                  <span className="text-sm text-slate-700">Recordar sesión</span>
                </label>
                <button 
                  type="button" 
                  className="text-sm font-medium text-white-600 transition-colors hover:text-blue-700 focus:outline-none focus:underline"
                >
                  ¿Olvidaste tu contraseña?
                </button>
              </div>

              {/* Botón de envío */}
              <button
                type="submit"
                disabled={!canSubmit}
                className="group w-full rounded-xl bg-gradient-to-r from-blue-600 via-cyan-600 to-emerald-600 px-4 py-3 font-semibold text-white shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <span className="flex items-center justify-center gap-2">
                  {submitting ? (
                    <>
                      <span className="h-5 w-5 animate-spin rounded-full border-2 border-white/40 border-t-white" />
                      Iniciando…
                    </>
                  ) : (
                    <>
                      Entrar
                      <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
                    </>
                  )}
                </span>
              </button>
            </form>
            
            {/* Credenciales de prueba */}

          </div>

          {/* Footer */}
          <div className="mt-8 text-center text-xs text-slate-500">
            © {new Date().getFullYear()} Clínica Central — Sistema de gestión
          </div>
        </div>
      </div>
    </main>
  );
}
