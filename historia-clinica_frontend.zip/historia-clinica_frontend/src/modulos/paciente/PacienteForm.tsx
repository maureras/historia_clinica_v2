// =============================================
// File: src/modulos/paciente/PacienteForm.tsx (versión final)
// =============================================
import React, { useState, useEffect, useRef } from "react";
import { Search, User, Users, Phone, Calendar, Check, X, AlertCircle, Hash, IdCard, UserCheck } from "lucide-react";

const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:4000";

// Interfaces
export interface PacienteData {
  id: number;
  nombres: string;
  apellidos: string;
  numeroIdentificacion: string;
  fechaNacimiento?: string;
  sexo?: string;
  email?: string;
  celular?: string;
  qrCode?: string;
  qrData?: string;
  foto?: string;
}

interface PacienteSugerencia {
  id: number;
  nombres: string;
  apellidos: string;
  numeroIdentificacion: string;
  celular?: string;
  ultimaVisita?: string;
}

interface PacienteFormProps {
  onChange: (paciente: PacienteData | null) => void;
  pacienteInicial?: PacienteData | null;
}

const PacienteForm: React.FC<PacienteFormProps> = ({ onChange, pacienteInicial = null }) => {
  // Estados principales
  const [query, setQuery] = useState("");
  const [sugerencias, setSugerencias] = useState<PacienteSugerencia[]>([]);
  const [pacienteSeleccionado, setPacienteSeleccionado] = useState<PacienteData | null>(pacienteInicial);
  const [showDropdown, setShowDropdown] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  
  // Estados de UI
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loadingPaciente, setLoadingPaciente] = useState(false);
  
  // Refs
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Función para detectar homónimos
  const detectarHomonimos = (pacientes: PacienteSugerencia[]) => {
    const nombresCompletos = pacientes.map(p => `${p.nombres} ${p.apellidos}`.toLowerCase());
    const nombres = pacientes.map(p => p.nombres.toLowerCase());
    
    return pacientes.map((paciente, index) => {
      const nombreCompleto = `${paciente.nombres} ${paciente.apellidos}`.toLowerCase();
      const nombre = paciente.nombres.toLowerCase();
      
      const homonimoCompleto = nombresCompletos.filter(n => n === nombreCompleto).length > 1;
      const homonimoNombre = nombres.filter(n => n === nombre).length > 1;
      
      return {
        ...paciente,
        esHomonimoCompleto: homonimoCompleto,
        esHomonimoNombre: homonimoNombre
      };
    });
  };

  // Función para buscar sugerencias
  const buscarSugerencias = async (termino: string) => {
    if (!termino || termino.length < 2) {
      setSugerencias([]);
      setShowDropdown(false);
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`${API_URL}/api/pacientes/buscar?nombre=${encodeURIComponent(termino)}`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(10000)
      });

      if (response.ok) {
        const result = await response.json();
        if (result.ok && Array.isArray(result.data)) {
          setSugerencias(result.data);
          setShowDropdown(true);
          setSelectedIndex(-1);
          return;
        }
      }

      throw new Error(`Error ${response.status}: ${response.statusText}`);
      
    } catch (err: any) {
      setError('Error al buscar pacientes. Verifique su conexión.');
      setSugerencias([]);
      setShowDropdown(false);
    } finally {
      setLoading(false);
    }
  };

  // Función para obtener datos completos del paciente
  const obtenerPacienteCompleto = async (pacienteSugerencia: PacienteSugerencia): Promise<PacienteData | null> => {
    setLoadingPaciente(true);
    try {
      const response = await fetch(`${API_URL}/api/pacientes/${pacienteSugerencia.numeroIdentificacion}`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(5000)
      });

      if (response.ok) {
        const result = await response.json();
        if (result.ok && result.data) {
          return result.data;
        }
      }

      // Fallback a datos básicos
      return {
        id: pacienteSugerencia.id,
        nombres: pacienteSugerencia.nombres,
        apellidos: pacienteSugerencia.apellidos,
        numeroIdentificacion: pacienteSugerencia.numeroIdentificacion,
        celular: pacienteSugerencia.celular
      };
    } catch (err) {
      return {
        id: pacienteSugerencia.id,
        nombres: pacienteSugerencia.nombres,
        apellidos: pacienteSugerencia.apellidos,
        numeroIdentificacion: pacienteSugerencia.numeroIdentificacion,
        celular: pacienteSugerencia.celular
      };
    } finally {
      setLoadingPaciente(false);
    }
  };

  // Manejar selección de paciente
  const seleccionarPaciente = async (sugerencia: PacienteSugerencia) => {
    try {
      const pacienteCompleto = await obtenerPacienteCompleto(sugerencia);
      
      if (pacienteCompleto) {
        setPacienteSeleccionado(pacienteCompleto);
        setQuery(`${pacienteCompleto.nombres} ${pacienteCompleto.apellidos} (${pacienteCompleto.numeroIdentificacion})`);
        setShowDropdown(false);
        setSelectedIndex(-1);
        setSugerencias([]);
        onChange(pacienteCompleto);
      } else {
        setError('Error al obtener datos del paciente');
      }
    } catch (error: any) {
      setError(`Error al seleccionar paciente: ${error.message}`);
    }
  };

  // Limpiar selección
  const limpiarSeleccion = () => {
    setQuery("");
    setPacienteSeleccionado(null);
    setSugerencias([]);
    setShowDropdown(false);
    setSelectedIndex(-1);
    setError(null);
    onChange(null);
    inputRef.current?.focus();
  };

  // Debounce para búsqueda
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (query && !pacienteSeleccionado) {
        buscarSugerencias(query);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [query, pacienteSeleccionado]);

  // Manejar teclado
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!showDropdown || sugerencias.length === 0) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => 
          prev < sugerencias.length - 1 ? prev + 1 : prev
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => prev > 0 ? prev - 1 : -1);
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && selectedIndex < sugerencias.length) {
          seleccionarPaciente(sugerencias[selectedIndex]);
        }
        break;
      case 'Escape':
        setShowDropdown(false);
        setSelectedIndex(-1);
        break;
    }
  };

  // Cerrar dropdown al hacer clic fuera
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
        setSelectedIndex(-1);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Formatear fecha
  const formatearFecha = (fechaStr?: string) => {
    if (!fechaStr) return null;
    try {
      return new Date(fechaStr).toLocaleDateString('es-ES', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      });
    } catch {
      return null;
    }
  };

  // Procesar sugerencias para detectar homónimos
  const sugerenciasConHomonimos = detectarHomonimos(sugerencias);

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-visible">
      {/* Header */}
      <div className="bg-blue-50 border-b border-blue-200 px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center">
            <Users className="h-4 w-4 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-blue-900">Seleccionar Paciente</h3>
            <p className="text-sm text-blue-700">Busque y seleccione el paciente para la consulta</p>
          </div>
        </div>
      </div>

      {/* Contenido */}
      <div className="p-6">
        {!pacienteSeleccionado ? (
          /* Modo búsqueda */
          <div className="space-y-4">
            <div className="relative" ref={dropdownRef}>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Buscar paciente
              </label>
              
              {/* Campo de búsqueda */}
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-slate-400" />
                </div>
                
                <input
                  ref={inputRef}
                  type="text"
                  value={query}
                  onChange={(e) => {
                    setQuery(e.target.value);
                    setError(null);
                  }}
                  onKeyDown={handleKeyDown}
                  onFocus={() => {
                    if (sugerencias.length > 0) {
                      setShowDropdown(true);
                    }
                  }}
                  placeholder="Escriba el nombre o cédula del paciente..."
                  className="block w-full pl-10 pr-10 py-3 border border-slate-300 rounded-xl shadow-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  disabled={loadingPaciente}
                />
                
                {/* Indicadores de estado */}
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center gap-2">
                  {loading && (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                  )}
                  {query && !loading && (
                    <button
                      onClick={() => setQuery("")}
                      className="text-slate-400 hover:text-slate-600"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Dropdown de sugerencias */}
              {showDropdown && (
                <div 
                  className="absolute z-[9999] mt-1 w-full bg-white shadow-2xl max-h-80 rounded-xl py-1 text-base ring-1 ring-black ring-opacity-10 overflow-auto border border-slate-200"
                  style={{ zIndex: 99999 }}
                >
                  {sugerenciasConHomonimos.length === 0 ? (
                    <div className="px-4 py-3 text-slate-500 text-center">
                      {loading ? "Buscando..." : "No se encontraron pacientes"}
                    </div>
                  ) : (
                    sugerenciasConHomonimos.map((paciente: any, index) => (
                      <div
                        key={`${paciente.id}-${paciente.numeroIdentificacion}`}
                        className={`cursor-pointer select-none relative py-4 px-4 hover:bg-blue-50 border-l-4 transition-all ${
                          index === selectedIndex 
                            ? 'bg-blue-50 text-blue-900 border-l-blue-500' 
                            : paciente.esHomonimoCompleto || paciente.esHomonimoNombre
                              ? 'border-l-amber-400 bg-amber-50/30'
                              : 'border-l-transparent text-slate-900'
                        }`}
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          seleccionarPaciente(paciente);
                        }}
                      >
                        {/* Indicador de homónimo */}
                        {(paciente.esHomonimoCompleto || paciente.esHomonimoNombre) && (
                          <div className="absolute top-2 right-2">
                            <div className="flex items-center gap-1 px-2 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-medium">
                              <AlertCircle className="h-3 w-3" />
                              <span>Homónimo</span>
                            </div>
                          </div>
                        )}

                        <div className="flex items-start gap-4">
                          {/* Avatar con ID */}
                          <div className="flex-shrink-0 relative">
                            <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${
                              paciente.esHomonimoCompleto || paciente.esHomonimoNombre
                                ? 'bg-amber-100'
                                : 'bg-slate-100'
                            }`}>
                              <User className={`h-6 w-6 ${
                                paciente.esHomonimoCompleto || paciente.esHomonimoNombre
                                  ? 'text-amber-600'
                                  : 'text-slate-600'
                              }`} />
                            </div>
                            <div className="absolute -top-1 -right-1 h-6 w-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">
                              {paciente.id}
                            </div>
                          </div>

                          <div className="flex-1 min-w-0">
                            {/* Nombre */}
                            <div className="flex items-center gap-2 mb-2">
                              <h4 className="font-semibold text-base text-slate-900 truncate">
                                {paciente.nombres} {paciente.apellidos}
                              </h4>
                              {(paciente.esHomonimoCompleto || paciente.esHomonimoNombre) && (
                                <span className="text-amber-600 text-xs">⚠️</span>
                              )}
                            </div>

                            {/* Información crítica */}
                            <div className="grid grid-cols-2 gap-2 mb-2">
                              <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 rounded-lg">
                                <Hash className="h-3 w-3 text-blue-600" />
                                <span className="text-xs font-medium text-blue-700">ID:</span>
                                <span className="text-sm font-bold text-blue-900">{paciente.id}</span>
                              </div>

                              <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 rounded-lg">
                                <IdCard className="h-3 w-3 text-green-600" />
                                <span className="text-xs font-medium text-green-700">CI:</span>
                                <span className="text-sm font-bold text-green-900 font-mono">{paciente.numeroIdentificacion}</span>
                              </div>
                            </div>

                            {/* Información adicional */}
                            <div className="flex items-center gap-4 text-xs text-slate-500">
                              {paciente.celular && (
                                <div className="flex items-center gap-1">
                                  <Phone className="h-3 w-3" />
                                  <span>{paciente.celular}</span>
                                </div>
                              )}
                              {paciente.ultimaVisita && (
                                <div className="flex items-center gap-1">
                                  <Calendar className="h-3 w-3" />
                                  <span>Última: {formatearFecha(paciente.ultimaVisita)}</span>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Check de selección */}
                          {index === selectedIndex && (
                            <div className="flex-shrink-0">
                              <Check className="h-5 w-5 text-blue-600" />
                            </div>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-center gap-2 p-3 border rounded-lg bg-red-50 border-red-200">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <span className="text-sm text-red-700">{error}</span>
              </div>
            )}

            {/* Ayuda */}
            <div className="text-xs text-slate-500 space-y-1">
              <p>💡 Escriba al menos 2 caracteres para buscar. Use ↑↓ para navegar y Enter para seleccionar.</p>
            </div>
          </div>
        ) : (
          /* Modo paciente seleccionado */
          <div className="space-y-4">
            {/* Indicador de carga */}
            {loadingPaciente && (
              <div className="flex items-center gap-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                <span className="text-sm text-blue-700">Cargando datos del paciente...</span>
              </div>
            )}

            {/* Información del paciente seleccionado */}
            <div className="p-4 bg-green-50 border border-green-200 rounded-xl">
              <div className="flex items-start gap-4">
                <div className="h-12 w-12 rounded-full bg-green-600 flex items-center justify-center flex-shrink-0 relative">
                  <UserCheck className="h-6 w-6 text-white" />
                  <div className="absolute -top-1 -right-1 h-6 w-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">
                    {pacienteSeleccionado.id}
                  </div>
                </div>
                <div className="flex-1">
                  <div className="font-medium text-green-900 text-lg mb-3">
                    Paciente seleccionado
                  </div>
                  
                  <div className="space-y-3">
                    <div className="p-3 bg-white rounded-lg border border-green-200">
                      <div className="font-semibold text-lg text-slate-900">
                        {pacienteSeleccionado.nombres} {pacienteSeleccionado.apellidos}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <div className="flex items-center gap-2">
                          <Hash className="h-4 w-4 text-blue-600" />
                          <span className="text-sm font-medium text-blue-700">ID Interno:</span>
                        </div>
                        <div className="text-xl font-bold text-blue-900 mt-1">
                          {pacienteSeleccionado.id}
                        </div>
                      </div>
                      
                      <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                        <div className="flex items-center gap-2">
                          <IdCard className="h-4 w-4 text-emerald-600" />
                          <span className="text-sm font-medium text-emerald-700">Cédula:</span>
                        </div>
                        <div className="text-xl font-bold text-emerald-900 font-mono mt-1">
                          {pacienteSeleccionado.numeroIdentificacion}
                        </div>
                      </div>
                    </div>
                    
                    {pacienteSeleccionado.celular && (
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-slate-600" />
                          <span className="text-sm font-medium text-slate-700">Teléfono:</span>
                          <span className="text-sm text-slate-900">{pacienteSeleccionado.celular}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <button
                  onClick={limpiarSeleccion}
                  className="p-2 text-green-600 hover:text-green-800 hover:bg-green-100 rounded-lg transition-colors"
                  title="Cambiar paciente"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            <button
              onClick={limpiarSeleccion}
              className="w-full py-2 px-4 text-sm text-slate-600 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Cambiar paciente
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PacienteForm;