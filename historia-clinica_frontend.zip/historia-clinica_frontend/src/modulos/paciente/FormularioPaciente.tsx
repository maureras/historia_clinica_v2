import React, { useEffect, useState } from "react";
import {
  User, Phone, CreditCard, MapPin, Camera, FileText, QrCode, Edit
} from "lucide-react";

// Alias en español (si ya tienes estos componentes en './ui')
import {
  InputField as CampoTexto,
  SelectField as CampoSeleccion,
  CheckboxField as CampoCasilla
} from "../../components/ui";

import QRCodeGenerator from "../../components/QRCodeGenerator";

// Interfaz (sin cambios)
export interface PatientData {
  nombres: string; apellidos: string; fechaNacimiento: string; sexo: string; email: string;
  celular: string; sinCelular: boolean; tipoIdentificacion: string; numeroIdentificacion: string;
  telefono: string; aceptaWhatsapp: boolean; enviarCorreo: boolean; direccion: string; pais: string;
  estado: string; ciudad: string; codigoPostal: string; numeroExterior: string; numeroInterior: string;
  notas: string; foto: string; edad: string; ocupacion: string; estadoCivil: string; contactoEmergencia: string;
}

// ← INTERFAZ ACTUALIZADA
interface Props {
  patient: PatientData;
  onPatientChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  qrData: string | null;
  pacienteId?: number;
  onGuardarTodo?: () => Promise<number>; // ← NUEVA: Función que guarda paciente y devuelve ID
  onCancelar?: () => void;
  onDescargarQR?: () => void;
  onQRSaved?: (qrData: { qrCode: string; qrData: string }) => void;
  initialLocked?: boolean;
  apiBaseUrl?: string;
}

const FormularioPaciente: React.FC<Props> = ({ 
  patient, 
  onPatientChange, 
  onFileChange, 
  qrData, 
  pacienteId,
  onGuardarTodo, // ← NUEVA PROP
  onCancelar, 
  onDescargarQR, 
  onQRSaved,
  initialLocked = false,
  apiBaseUrl = "http://localhost:4000"
}) => {
  const [locked, setLocked] = useState(initialLocked);

  // Calcula edad automáticamente
  useEffect(() => {
    if (patient.fechaNacimiento && !locked) {
      const hoy = new Date();
      const nacimiento = new Date(patient.fechaNacimiento);
      let edad = hoy.getFullYear() - nacimiento.getFullYear();
      const diffMes = hoy.getMonth() - nacimiento.getMonth();
      if (diffMes < 0 || (diffMes === 0 && hoy.getDate() < nacimiento.getDate())) edad--;
      if (edad >= 0 && edad.toString() !== patient.edad) {
        const syntheticEvent = {
          target: { name: "edad", value: edad.toString(), type: "text" }
        } as React.ChangeEvent<HTMLInputElement>;
        onPatientChange(syntheticEvent);
      }
    }
  }, [patient.fechaNacimiento, patient.edad, onPatientChange, locked]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    if (locked) {
      e.preventDefault();
      return;
    }
    onPatientChange(e);
  };

  const handleEditar = () => {
    setLocked(false);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="space-y-6">
          {/* ← HEADER SIN BOTÓN GUARDAR */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-semibold text-slate-900">
                  {locked ? "Información del paciente" : "Nuevo paciente"}
                </h1>
                <p className="text-sm text-slate-600 mt-1">
                  {locked ? "Datos guardados - Solo lectura" : "Complete el formulario y haga clic en 'Guardar' en el código QR"}
                </p>
                {process.env.NODE_ENV === 'development' && (
                  <p className="text-xs text-gray-500 mt-1">
                  </p>
                )}
              </div>
              <div className="flex items-center gap-3">
                {/* ← SOLO BOTÓN EDITAR O CANCELAR, NO GUARDAR */}
                {locked && (
                  <button
                    onClick={handleEditar}
                    className="inline-flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 transition-colors"
                  >
                    <Edit size={16} />
                    Editar
                  </button>
                )}
                
                <button
                  onClick={() => onCancelar?.()}
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-offset-2 transition-colors"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>

          {/* Contenido principal */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

            {/* Sidebar mejorado */}
            <div className="lg:col-span-4 space-y-6">
              <fieldset disabled={locked}>
                <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="bg-blue-50 border-b border-blue-200 px-4 py-3">
                    <h3 className="font-semibold text-blue-900 flex items-center gap-2 text-sm">
                      <Camera className="w-5 h-5 text-blue-600" />Fotografía
                    </h3>
                  </div>
                  <div className="p-6 flex flex-col items-center space-y-4">
                    {patient.foto ? (
                      <img src={patient.foto} alt="Foto Paciente" className="w-32 h-32 rounded-full object-cover shadow-lg border-4 border-slate-100" />
                    ) : (
                      <div className="w-32 h-32 rounded-full bg-slate-100 flex items-center justify-center border-4 border-slate-200">
                        <User className="w-16 h-16 text-slate-400" />
                      </div>
                    )}
                    {!locked && (
                      <label className="text-sm font-medium text-sky-600 hover:text-sky-700 cursor-pointer px-3 py-2 rounded-lg hover:bg-sky-50 transition-colors border border-sky-200">
                        Subir / Cambiar Foto
                        <input type="file" accept="image/*" className="hidden" onChange={onFileChange} />
                      </label>
                    )}
                  </div>
                </div>

                <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="bg-amber-50 border-b border-amber-200 px-4 py-3">
                    <h3 className="font-semibold text-amber-900 flex items-center gap-2 text-sm">
                      <FileText className="w-5 h-5 text-amber-600" />Notas internas
                    </h3>
                  </div>
                  <div className="p-4">
                    <textarea
                      name="notas"
                      value={patient.notas}
                      onChange={handleChange}
                      rows={6}
                      placeholder="Anotaciones especiales..."
                      disabled={locked}
                      className={`w-full text-sm px-3 py-3 border rounded-xl focus:outline-none focus:ring-2 transition-colors resize-none ${
                        locked ? 'border-slate-200 bg-slate-50 text-slate-500 cursor-not-allowed' : 'border-slate-300 bg-white text-slate-800 focus:border-amber-500 focus:ring-amber-200'
                      }`}
                    />
                  </div>
                </div>
              </fieldset>

              {/* ← SECCIÓN DEL QR CON GUARDADO UNIFICADO */}
              {qrData && (
                <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="bg-emerald-50 border-b border-emerald-200 px-4 py-3">
                    <h3 className="font-semibold text-emerald-900 flex items-center justify-center gap-2 text-sm">
                      <QrCode className="w-5 h-5 text-emerald-600" />Código QR
                      {/* Indicador si ya está guardado */}
                      {pacienteId && (
                        <span className="ml-auto">
                          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" title="Paciente guardado"></div>
                        </span>
                      )}
                    </h3>
                  </div>
                  
                  <div className="p-6 flex flex-col items-center space-y-4">
                    {/* ← QR GENERATOR CON GUARDADO UNIFICADO */}
                    <QRCodeGenerator 
                      value={qrData} 
                      pacienteId={pacienteId}
                      onSaved={onQRSaved}
                      showSaveButton={true} // ← Siempre mostrar
                      apiBaseUrl={apiBaseUrl}
                      onGuardarTodo={onGuardarTodo} // ← NUEVA PROP para guardar todo
                      patientData={patient} // ← NUEVA PROP con datos del paciente
                    />
                    
                    {/* Info adicional */}
                    <div className="text-center">
                      <p className="text-xs text-slate-500">
                        {pacienteId ? (
                          <>ID del paciente: <span className="font-mono font-medium">{pacienteId}</span></>
                        ) : (
                          <>Haga clic en "Guardar" para crear el paciente y guardar el QR</>
                        )}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Form principal - SIN CAMBIOS */}
            <fieldset disabled={locked} className="lg:col-span-8">
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                {locked && (
                  <div className="bg-emerald-50 border-b border-emerald-200 p-4">
                    <div className="flex items-center gap-2 text-emerald-800">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                      <span className="text-sm font-medium">Información guardada exitosamente. Los campos están bloqueados para prevenir cambios accidentales.</span>
                    </div>
                  </div>
                )}

                <div className="p-6 space-y-8">
                  {/* Información personal */}
                  <section className="space-y-4">
                    <div className="flex items-center gap-3 pb-2 border-b border-slate-200">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <User className="w-5 h-5 text-blue-600" />
                      </div>
                      <h3 className="text-lg font-semibold text-slate-900">Información personal</h3>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <CampoTexto label="Nombre(s)" name="nombres" value={patient.nombres} onChange={handleChange} required disabled={locked} />
                      <CampoTexto label="Apellido(s)" name="apellidos" value={patient.apellidos} onChange={handleChange} required disabled={locked} />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <CampoTexto type="date" label="Fecha de nacimiento" name="fechaNacimiento" value={patient.fechaNacimiento} onChange={handleChange} required disabled={locked} />
                      <CampoSeleccion label="Sexo" name="sexo" value={patient.sexo} onChange={handleChange} required disabled={locked}>
                        <option value="Masculino">Masculino</option>
                        <option value="Femenino">Femenino</option>
                        <option value="Otro">Otro</option>
                      </CampoSeleccion>
                      <CampoTexto readOnly label="Edad" name="edad" value={patient.edad} onChange={() => {}} placeholder="Automático" disabled />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <CampoSeleccion label="Estado civil" name="estadoCivil" value={patient.estadoCivil} onChange={handleChange} placeholder="Seleccione..." disabled={locked}>
                        <option value="Soltero(a)">Soltero(a)</option>
                        <option value="Casado(a)">Casado(a)</option>
                        <option value="Divorciado(a)">Divorciado(a)</option>
                        <option value="Viudo(a)">Viudo(a)</option>
                        <option value="Unión libre">Unión libre</option>
                      </CampoSeleccion>
                      <CampoTexto label="Ocupación" name="ocupacion" value={patient.ocupacion} onChange={handleChange} disabled={locked} />
                    </div>
                  </section>

                  {/* Información de contacto */}
                  <section className="space-y-4">
                    <div className="flex items-center gap-3 pb-2 border-b border-slate-200">
                      <div className="p-2 bg-emerald-100 rounded-lg">
                        <Phone className="w-5 h-5 text-emerald-600" />
                      </div>
                      <h3 className="text-lg font-semibold text-slate-900">Información de contacto</h3>
                    </div>

                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <CampoTexto label="Correo electrónico" name="email" type="email" value={patient.email} onChange={handleChange} required disabled={locked} />
                        <CampoTexto label="Teléfono celular" name="celular" type="tel" value={patient.celular} onChange={handleChange} required={!patient.sinCelular} disabled={locked} />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <CampoTexto label="Contacto de emergencia" name="contactoEmergencia" value={patient.contactoEmergencia} onChange={handleChange} placeholder="Nombre y teléfono" disabled={locked} />
                        <CampoTexto label="Teléfono de emergencia" name="telefono" value={patient.telefono} onChange={handleChange} disabled={locked} />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-slate-50 rounded-xl">
                      <CampoCasilla name="sinCelular" label="No tiene celular" checked={patient.sinCelular} onChange={handleChange} disabled={locked} />
                      <CampoCasilla name="aceptaWhatsapp" label="Acepta WhatsApp" checked={patient.aceptaWhatsapp} onChange={handleChange} disabled={locked} />
                      <CampoCasilla name="enviarCorreo" label="Acepta correos" checked={patient.enviarCorreo} onChange={handleChange} disabled={locked} />
                    </div>
                  </section>

                  {/* Identificación */}
                  <section className="space-y-4">
                    <div className="flex items-center gap-3 pb-2 border-b border-slate-200">
                      <div className="p-2 bg-indigo-100 rounded-lg">
                        <CreditCard className="w-5 h-5 text-indigo-600" />
                      </div>
                      <h3 className="text-lg font-semibold text-slate-900">Identificación</h3>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <CampoSeleccion label="Tipo de identificación" name="tipoIdentificacion" value={patient.tipoIdentificacion} onChange={handleChange} required disabled={locked}>
                        <option value="Cédula">Cédula</option>
                        <option value="Pasaporte">Pasaporte</option>
                      </CampoSeleccion>
                      <CampoTexto label="Número de identificación" name="numeroIdentificacion" value={patient.numeroIdentificacion} onChange={handleChange} required disabled={locked} />
                    </div>
                  </section>

                  {/* Información demográfica */}
                  <section className="space-y-4">
                    <div className="flex items-center gap-3 pb-2 border-b border-slate-200">
                      <div className="p-2 bg-amber-100 rounded-lg">
                        <MapPin className="w-5 h-5 text-amber-600" />
                      </div>
                      <h3 className="text-lg font-semibold text-slate-900">Información demográfica</h3>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <CampoTexto label="País" name="pais" value={patient.pais} onChange={handleChange} disabled={locked} />
                      <CampoTexto label="Estado / Provincia" name="estado" value={patient.estado} onChange={handleChange} disabled={locked} />
                      <CampoTexto label="Ciudad" name="ciudad" value={patient.ciudad} onChange={handleChange} disabled={locked} />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <CampoTexto label="Dirección" name="direccion" value={patient.direccion} onChange={handleChange} disabled={locked} />
                      <CampoTexto label="Código postal" name="codigoPostal" value={patient.codigoPostal} onChange={handleChange} disabled={locked} />
                    </div>
                  </section>
                </div>
              </div>
            </fieldset>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FormularioPaciente;