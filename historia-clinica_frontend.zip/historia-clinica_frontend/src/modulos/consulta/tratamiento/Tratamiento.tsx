import React from 'react';
import { Pill } from 'lucide-react';
import { FormField, Alert } from '../../../components/ui';

// --- Tipos de Datos ---
export interface TratamientoData {
  medicamentos: string;
  indicaciones: string;
  recomendaciones: string;
  proximaCita: string;
}

// --- Props del Componente ---
interface TratamientoFormProps {
  data: TratamientoData;
  onChange: (data: TratamientoData) => void;
  readOnly: boolean;
}

// --- El Componente del Formulario ---
const TratamientoForm: React.FC<TratamientoFormProps> = ({ data, onChange, readOnly }) => {

  const updateField = (field: keyof TratamientoData, value: string) => {
    onChange({
      ...data,
      [field]: value,
    });
  };

  return (
    <div className="space-y-6">
      <fieldset disabled={readOnly} className="space-y-8">

        {readOnly && (
          <div className="rounded-lg border border-sky-200 bg-sky-50 p-4">
            <div className="flex items-center gap-2 text-sky-800 text-sm">
              <div className="w-2 h-2 bg-sky-500 rounded-full"></div>
              <span>Primero debe guardar los datos de un paciente para poder registrar el plan de tratamiento.</span>
            </div>
          </div>
        )}

        <section className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-200">
            <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
            Prescripción Farmacológica
          </h3>
          <FormField
            label="Tratamiento Farmacológico (Prescripción)"
            value={data.medicamentos}
            onChange={(value) => updateField('medicamentos', value)}
            multiline
            rows={6}
            placeholder="Ej: Losartán 50mg VO c/24h #30 tabletas..."
          />
        </section>

        <section className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-200">
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            Indicaciones Terapéuticas
          </h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <FormField
              label="Indicaciones Médicas"
              value={data.indicaciones}
              onChange={(value) => updateField('indicaciones', value)}
              multiline
              rows={6}
              placeholder="Ej: Reposo relativo, dieta blanda, aplicar calor local..."
            />
            <FormField
              label="Recomendaciones y Educación"
              value={data.recomendaciones}
              onChange={(value) => updateField('recomendaciones', value)}
              multiline
              rows={6}
              placeholder="Ej: Mantener hidratación, evitar automedicación, signos de alarma..."
            />
          </div>
        </section>

        <section className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-200">
            <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
            Plan de Seguimiento
          </h3>
          <FormField
            label="Plan de Seguimiento y Próxima Cita"
            value={data.proximaCita}
            onChange={(value) => updateField('proximaCita', value)}
            multiline
            rows={6}
            placeholder="Ej: Control en 7 días para reevaluación, laboratorios de control en 2 semanas..."
          />
        </section>
      </fieldset>
    </div>
  );
};

export default TratamientoForm;