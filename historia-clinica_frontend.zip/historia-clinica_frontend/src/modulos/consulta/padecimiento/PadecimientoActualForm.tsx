// src/components/forms/PadecimientoActualForm.tsx
import React from "react";
import { AlertTriangle } from "lucide-react";
// desde components/forms hacia components/ui es un nivel:
import { FormField, Alert } from "../../../components/ui";
import type { PadecimientoActualData as CoreData } from "@/modulos/consulta/tipos";

export interface PadecimientoActualFormProps {
  value: CoreData | null;
  onChange: (v: CoreData | null) => void;
  readOnly?: boolean;
}

const PadecimientoActualForm: React.FC<PadecimientoActualFormProps> = ({
  value,
  onChange,
  readOnly = false,
}) => {
  const v = value ?? {};
  const set = (patch: Partial<CoreData>) => onChange({ ...v, ...patch });

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm cursor-pointer transition hover:shadow-md hover:border-sky-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700">
          <div className="inline-flex items-center gap-2 rounded-full px-2.5 py-1 text-xs font-medium ring-1 bg-amber-100 text-amber-700 ring-amber-200">
            <AlertTriangle className="h-5 w-5" />
            <span>Padecimiento Actual</span>
          </div>
        </div>
        {!readOnly && (
          <div className="flex items-center gap-1 text-xs font-medium text-blue-600">
            <div className="h-4 w-4 rounded-full bg-blue-500 flex items-center justify-center">
              <div className="h-2 w-2 rounded-full bg-white"></div>
            </div>
            En Proceso
          </div>
        )}
      </div>

      <div className="mt-2 flex items-center gap-4 text-sm text-slate-600">
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-4 w-4" />
          Registro de síntomas y evolución del paciente
        </div>
      </div>

      <fieldset disabled={readOnly} className="mt-4 space-y-6">
        {readOnly && (
          <div className="rounded-lg border border-sky-200 bg-sky-50 p-4">
            <div className="flex items-center gap-2 text-sky-800 text-sm">
              <div className="w-2 h-2 bg-sky-500 rounded-full"></div>
              <span>Primero debe guardar los datos de un paciente para poder registrar su padecimiento actual.</span>
            </div>
          </div>
        )}

        <div className="space-y-6">
          <FormField
            label="Motivo de Consulta"
            value={v.motivo ?? ""}
            onChange={(val) => set({ motivo: val })}
            multiline
            rows={3}
            placeholder="¿Por qué acude el paciente? (Ej: Dolor abdominal, seguimiento, etc.)"
          />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <FormField
              label="Inicio y evolución de los síntomas"
              value={v.tiempo ?? ""}
              onChange={(val) => set({ tiempo: val })}
              multiline
              rows={4}
              placeholder="¿Cuándo comenzaron y cómo han evolucionado?"
            />

            <FormField
              label="Síntomas asociados"
              value={v.sintomasAsociados ?? ""}
              onChange={(val) => set({ sintomasAsociados: val })}
              multiline
              rows={4}
              placeholder="Fiebre, náuseas, mareos, etc."
            />
          </div>

          <FormField
            label="Descripción / evolución"
            value={v.descripcion ?? ""}
            onChange={(val) => set({ descripcion: val })}
            multiline
            rows={4}
          />

          <FormField
            label="Tratamiento previo recibido"
            value={v.tratamientoPrevio ?? ""}
            onChange={(val) => set({ tratamientoPrevio: val })}
            multiline
            rows={4}
            placeholder="¿Qué tratamientos recibió? ¿Fueron efectivos?"
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="text-xs text-slate-500">Complete la información del padecimiento actual</div>
          <div className="text-slate-400">→</div>
        </div>
      </fieldset>
    </div>
  );
};

export default PadecimientoActualForm;