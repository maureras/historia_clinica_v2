import React, { useState } from 'react';
import { Search } from 'lucide-react';

// --- Tipos de Datos ---
export interface DiagnosticoData {
  impresionClinica: string;
  principal: string;
  secundarios: string;
  diferencial: string;
  cie10: string;
}

interface DiagnosticoFormProps {
  data: DiagnosticoData;
  onChange: (data: DiagnosticoData) => void;
  readOnly?: boolean;
}

// --- El Componente del Formulario ---
const DiagnosticoForm: React.FC<DiagnosticoFormProps> = ({ data, onChange, readOnly = false }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const updateField = (field: keyof DiagnosticoData, value: string) => {
    onChange({ ...data, [field]: value });
  };

  // Datos de ejemplo para el buscador CIE-10
  const commonCIE10 = [
    { code: 'I10', description: 'Hipertensión esencial (primaria)' },
    { code: 'E11.9', description: 'Diabetes mellitus tipo 2, sin complicaciones' },
    { code: 'J06.9', description: 'Infección aguda de las vías respiratorias superiores, no especificada' },
    { code: 'R51', description: 'Cefalea' },
    { code: 'K30', description: 'Dispepsia' },
    { code: 'Z00.0', description: 'Examen médico general' },
  ];

  const filteredCIE10 = searchTerm
    ? commonCIE10.filter(item =>
        item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  const selectCIE10 = (code: string, description: string) => {
    updateField('cie10', `${code} - ${description}`);
    setSearchTerm('');
  };

  return (
    <div className="space-y-6">
      <section className="space-y-4">
        <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-200">
          <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
          Evaluación Diagnóstica
        </h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Diagnóstico Principal</label>
            <textarea
              value={data.principal}
              onChange={(e) => updateField('principal', e.target.value)}
              disabled={readOnly}
              rows={5}
              placeholder="El diagnóstico más probable basado en la evidencia clínica..."
              className="w-full rounded-xl border px-3 py-2 text-sm shadow-sm transition-colors focus:outline-none focus:ring-2 border-slate-300 bg-white text-slate-800 focus:border-sky-500 focus:ring-sky-200 resize-none"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Diagnósticos Secundarios</label>
            <textarea
              value={data.secundarios}
              onChange={(e) => updateField('secundarios', e.target.value)}
              disabled={readOnly}
              rows={5}
              placeholder="Comorbilidades y condiciones adicionales presentes (ej: Obesidad, Dislipidemia...)"
              className="w-full rounded-xl border px-3 py-2 text-sm shadow-sm transition-colors focus:outline-none focus:ring-2 border-slate-300 bg-white text-slate-800 focus:border-sky-500 focus:ring-sky-200 resize-none"
            />
          </div>
          <div className="lg:col-span-2 space-y-2">
            <label className="text-sm font-medium text-slate-700">Diagnóstico Diferencial</label>
            <textarea
              value={data.diferencial}
              onChange={(e) => updateField('diferencial', e.target.value)}
              disabled={readOnly}
              rows={4}
              placeholder="Otras posibilidades diagnósticas a considerar o descartar..."
              className="w-full rounded-xl border px-3 py-2 text-sm shadow-sm transition-colors focus:outline-none focus:ring-2 border-slate-300 bg-white text-slate-800 focus:border-sky-500 focus:ring-sky-200 resize-none"
            />
          </div>
        </div>
      </section>

      <section className="space-y-4">
        <h4 className="text-lg font-semibold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-200">
          <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
          Clasificación CIE-10
        </h4>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Código CIE-10 Principal</label>
            <input
              name="cie10"
              value={data.cie10}
              onChange={(e) => updateField('cie10', e.target.value)}
              disabled={readOnly}
              placeholder="Seleccione de la lista o ingrese manualmente"
              className="w-full rounded-xl border px-3 py-2 text-sm shadow-sm transition-colors focus:outline-none focus:ring-2 border-slate-300 bg-white text-slate-800 focus:border-sky-500 focus:ring-sky-200"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
              <Search className="w-4 h-4 text-slate-500" />
              Buscar CIE-10
            </label>
            <input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              disabled={readOnly}
              placeholder="Buscar por código o descripción..."
              className="w-full rounded-xl border px-3 py-2 text-sm shadow-sm transition-colors focus:outline-none focus:ring-2 border-slate-300 bg-white text-slate-800 focus:border-sky-500 focus:ring-sky-200"
            />
          </div>
        </div>

{/* Resultados buscador CIE-10 */}
{searchTerm && !readOnly && (
  // 1. El contenedor ahora solo gestiona el espaciado y el scroll
  <div className="mt-4 max-h-48 overflow-y-auto space-y-2 pr-2">
    {filteredCIE10.length > 0 ? (
      filteredCIE10.map((item) => (
        <button
          key={item.code}
          onClick={() => selectCIE10(item.code, item.description)}
          // 2. Aquí aplicamos el nuevo estilo a cada botón
          className="w-full text-left p-3 rounded-xl bg-indigo-600 text-white shadow-md hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-400 transition-all"
        >
          <div className="font-mono text-sm font-semibold">{item.code}</div>
          <div className="text-sm opacity-90">{item.description}</div>
        </button>
      ))
    ) : (
      <div className="p-3 text-sm text-slate-500">No se encontraron resultados.</div>
    )}
  </div>
)}
      </section>
    </div>
  );
};

export default DiagnosticoForm;