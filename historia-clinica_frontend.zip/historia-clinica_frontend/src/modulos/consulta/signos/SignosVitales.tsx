import React, { useEffect } from 'react';
import { Activity, Save, Thermometer, Heart, Droplets, Gauge, Weight, Ruler, Calculator, Droplet } from 'lucide-react';
import { InputField, Button, Alert, SelectField } from '../../../components/ui';

// --- Tipos de Datos ---
export interface SignosVitalesData {
  temperatura: string;
  presionSistolica: string;
  presionDiastolica: string;
  frecuenciaCardiaca: string;
  frecuenciaRespiratoria: string;
  saturacionOxigeno: string;
  peso: string;
  talla: string;
  imc: string;
  tipoSangre: string;
}
// ---- Adaptador de props (value/onChange) ----
export type SignosVitalesModuleProps = {
  value: SignosVitalesData | null;
  onChange: (v: SignosVitalesData | null) => void;
  readOnly?: boolean;
  isLoading?: boolean;
  onSave?: () => void;
};

const SignosVitales: React.FC<SignosVitalesModuleProps> = ({
  value,
  onChange,
  readOnly = false,
  isLoading = false,
  onSave,
}) => {
  const data: SignosVitalesData = value ?? {
    temperatura: "",
    presionSistolica: "",
    presionDiastolica: "",
    frecuenciaCardiaca: "",
    frecuenciaRespiratoria: "",
    saturacionOxigeno: "",
    peso: "",
    talla: "",
    imc: "",
    tipoSangre: "",
  };

  const handleChange = (field: keyof SignosVitalesData, val: string) =>
    onChange({ ...data, [field]: val });

  return (
    <SignosVitalesForm
      data={data}
      onChange={handleChange}
      onSave={onSave ?? (() => {})}
      isLoading={isLoading}
      readOnly={readOnly}
    />
  );
};

export default SignosVitales;
interface SignosVitalesFormProps {
  data: SignosVitalesData;
  onChange: (field: keyof SignosVitalesData, value: string) => void;
  onSave: () => void;
  isLoading: boolean;
  readOnly: boolean;
}

// --- Configuración de los campos con sus iconos Y COLORES ---
const vitalSignsConfig = [
  { key: 'temperatura' as const, label: 'Temperatura', unit: '°C', icon: Thermometer, placeholder: '36.5', color: 'text-orange-500' },
  { key: 'frecuenciaCardiaca' as const, label: 'Frec. Cardíaca', unit: 'lpm', icon: Heart, placeholder: '75', color: 'text-red-500' },
  { key: 'frecuenciaRespiratoria' as const, label: 'Frec. Respiratoria', unit: 'rpm', icon: Droplets, placeholder: '16', color: 'text-cyan-500' },
  { key: 'presionSistolica' as const, label: 'P. Sistólica', unit: 'mmHg', icon: Activity, placeholder: '120', color: 'text-blue-500' },
  { key: 'presionDiastolica' as const, label: 'P. Diastólica', unit: 'mmHg', icon: Activity, placeholder: '80', color: 'text-blue-600' },
  { key: 'saturacionOxigeno' as const, label: 'Sat. Oxígeno', unit: '%', icon: Gauge, placeholder: '98', color: 'text-green-500' },
  { key: 'peso' as const, label: 'Peso', unit: 'kg', icon: Weight, placeholder: '70.5', color: 'text-purple-500' },
  { key: 'talla' as const, label: 'Talla', unit: 'cm', icon: Ruler, placeholder: '175', color: 'text-indigo-500' },
];

// --- Componente ---
const SignosVitalesForm: React.FC<SignosVitalesFormProps> = ({ data, onChange, onSave, isLoading, readOnly }) => {
  
  useEffect(() => {
    const pesoNum = parseFloat(data.peso);
    const tallaNum = parseFloat(data.talla);
    if (!isNaN(pesoNum) && !isNaN(tallaNum) && tallaNum > 0) {
      const tallaMts = tallaNum / 100;
      const imcCalculado = (pesoNum / (tallaMts * tallaMts)).toFixed(1);
      if (imcCalculado !== data.imc) onChange('imc', imcCalculado);
    } else if (data.imc !== '') {
      onChange('imc', '');
    }
  }, [data.peso, data.talla, data.imc, onChange]);

  return (
    <div className="space-y-4">
      <fieldset disabled={readOnly || isLoading} className="space-y-6">        
        {readOnly && (
          <div className="rounded-lg border border-sky-200 bg-sky-50 p-4">
            <div className="flex items-center gap-2 text-sky-800 text-sm">
              <div className="w-2 h-2 bg-sky-500 rounded-full"></div>
              <span>Primero debe guardar los datos de un paciente para poder registrar sus signos vitales.</span>
            </div>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {vitalSignsConfig.map(config => {
            const Icon = config.icon;
            return (
              <div key={config.key} className="flex flex-col space-y-2">
                <label htmlFor={config.key} className="text-sm font-medium text-slate-700 flex items-center gap-2">
                  <Icon className={`w-4 h-4 ${config.color || ''}`} />
                  {`${config.label}${config.unit ? ` (${config.unit})` : ''}`}
                </label>
                <input
                  id={config.key}
                  name={config.key}
                  type="number"
                  value={data[config.key]}
                  onChange={(e) => onChange(config.key, e.target.value)}
                  placeholder={config.placeholder}
                  className="w-full rounded-xl border px-3 py-2 text-sm shadow-sm transition-colors focus:outline-none focus:ring-2 border-slate-300 bg-white text-slate-800 focus:border-sky-500 focus:ring-sky-200 disabled:border-slate-200 disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed"
                />
              </div>
            );
          })}

          {/* Selector para Tipo de Sangre */}
          <div className="flex flex-col space-y-2">
            <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
              <Droplet className="text-red-500 w-4 h-4" />
              Tipo de Sangre
            </label>
            <select
              name="tipoSangre"
              value={data.tipoSangre}
              onChange={(e) => onChange('tipoSangre', e.target.value)}
              className="w-full rounded-xl border px-3 py-2 text-sm shadow-sm transition-colors focus:outline-none focus:ring-2 border-slate-300 bg-white text-slate-800 focus:border-sky-500 focus:ring-sky-200 disabled:border-slate-200 disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed"
            >
              <option value="">Seleccione tipo de sangre</option>
              <option value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
            </select>
          </div>

          <div className="flex flex-col space-y-2">
            <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
              <Calculator className="w-4 h-4 text-blue-700" />
              IMC (kg/m²)
            </label>
            <input
              name="imc"
              value={data.imc}
              readOnly
              placeholder="Calculado automáticamente"
              className="w-full rounded-xl border px-3 py-2 text-sm shadow-sm border-slate-200 bg-slate-100 text-slate-500 cursor-not-allowed"
            />
          </div>
        </div>

        
      </fieldset>
    </div>
  );
};