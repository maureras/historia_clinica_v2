// =============================================
// File: src/modulos/consulta/tipos.ts
// =============================================
export type PadecimientoActualData = {
  motivo?: string;
  tiempo?: string;
  descripcion?: string;
  sintomasAsociados?: string;
  tratamientoPrevio?: string;
};

export type SignosVitalesData = {
  fc?: number; // lpm
  fr?: number; // rpm
  pa?: string; // "120/80"
  temp?: number; // °C
  sat?: number; // %
  peso?: number; // kg
  talla?: number; // cm
};

export type DiagnosticoData = {
  cie10?: string;
  descripcion?: string;
  impresionClinica?: string;
};

export type TratamientoData = {
  indicaciones?: string;
  prescripciones?: string;
};

export type ConsultaData = {
  pacienteId: string;
  padecimiento: PadecimientoActualData | null;
  signos: SignosVitalesData | null;
  diagnostico: DiagnosticoData | null;
  tratamiento: TratamientoData | null;
    exploracionFisica?: ExploracionFisicaData | null; // <-- NUEVO CAMPO

};

export type ExploracionFisicaData = {
  exploracionGeneral: {
    aspectoGeneral: string; estadoConciencia: string; orientacion: string;
    hidratacion: string; coloracion: string; constitucion: string;
    actitud: string; facies: string; marcha: string;
  };
  exploracionSistemas: {
    cabezaCuello: string; cardiopulmonar: string; abdomen: string;
    extremidades: string; neurologico: string; piel: string;
    ganglios: string; genitourinario: string;
  };
  hallazgosEspecificos: {
    hallazgosNormales: string[];
    hallazgosAnormales: string[];
    impresionClinica: string;
  };
  observacionesGenerales: string;
  fechaExploracion: string;
  exploradoPor: string;
};


