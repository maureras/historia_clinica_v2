// =============================================
// File: src/modulos/consulta/FormularioConsulta.tsx
// =============================================
import React from "react";
import type { PadecimientoActualData } from "../../modulos/consulta/tipos";
import PadecimientoActual from "./padecimiento/PadecimientoActualForm";
import SignosVitales, { type SignosVitalesData } from "./signos/SignosVitales";
import ExploracionFisica from "./exploracion/ExploracionFisicaForm";


// ✅ Definición única de ConsultaData
export type ConsultaData = {
  pacienteId: string;
  motivo?: string;
  tiempo?: string;
  descripcion?: string;
  fc?: string;
  fr?: string;
  pa?: string;
  temp?: string;
  sat?: string;
  peso?: string;
  talla?: string;
  cie10?: string;
  diagnostico?: string;
  impresionClinica?: string;
  indicaciones?: string;
  prescripciones?: string;
  padecimiento?: PadecimientoActualData | null;
  signos?: SignosVitalesData | null;
};

type Props = {
  data: ConsultaData;
  onChange: (data: ConsultaData) => void;
  onFinalizar: () => void;
  onCancelar: () => void;
};

export default function FormularioConsulta({ data, onChange, onFinalizar, onCancelar }: Props) {
  const onPatch = (patch: Partial<ConsultaData>) =>
    onChange({ ...data, ...patch });

  return (
    <div className="space-y-6">
      {/* Módulo Padecimiento Actual */}
      <PadecimientoActual
        value={data.padecimiento ?? null}
        onChange={(v) => onPatch({ padecimiento: v })}
      />

      {/* Módulo Signos Vitales */}
      <SignosVitales
        value={data.signos ?? null}
        onChange={(v) => onPatch({ signos: v })}
      />

      {/* Botones */}
      <div className="flex gap-3">
        <button
          type="button"
          onClick={onFinalizar}
          className="bg-green-600 text-white px-4 py-2 rounded-lg"
        >
          Finalizar
        </button>
        <button
          type="button"
          onClick={onCancelar}
          className="bg-gray-500 text-white px-4 py-2 rounded-lg"
        >
          Cancelar
        </button>
      </div>
    </div>
  );
}