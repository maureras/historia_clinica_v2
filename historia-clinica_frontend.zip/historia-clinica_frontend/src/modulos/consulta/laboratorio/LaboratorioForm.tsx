// src/modulos/consulta/laboratorio/LaboratorioForm.tsx
import React, { useState, useEffect } from 'react';
import { Upload, Plus, FileText, CheckCircle2, AlertTriangle } from 'lucide-react';
import { Button, Alert } from '../../../components/ui';

// util simple para clases condicionales
const cx = (...args: (string | false | null | undefined)[]) => args.filter(Boolean).join(' ');

// --- Definimos los tipos de datos que esperamos de la API ---
interface Resultado {
  prueba: string;
  valor: string;
  unidad: string | null;
  rango: string | null;
}

interface Documento {
  archivo: string;
  fecha_informe: string | null;
  identificadores: {
    nombres: string | null;
    documento: string | null;
  };
  resultados: Resultado[];
}

interface ServerResponse {
  documentos: Documento[];
  resumen_hallazgos: string | null;
}

interface Hallazgo extends Resultado {
    estado: 'alto' | 'bajo';
    archivo: string;
}

// --- El Componente del Formulario con Lógica de Análisis ---
const LaboratorioForm: React.FC<{ pacienteId?: string }> = ({ pacienteId }) => {
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [serverData, setServerData] = useState<ServerResponse | null>(null);
  const [hallazgos, setHallazgos] = useState<Hallazgo[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // --- Funciones para analizar valores y rangos ---
  const parseRange = (raw?: string | null) => {
    if (!raw) return null;
    const s = String(raw);
    let m = s.match(/(-?\d+(?:[.,]\d+)?)\s*[-–]\s*(-?\d+(?:[.,]\d+)?)/);
    if (!m) m = s.match(/\[\s*(-?\d+(?:[.,]\d+)?)\s*[-–]\s*(-?\d+(?:[.,]\d+)?)\s*\]/);
    if (!m) return null;
    const min = parseFloat(m[1].replace(',', '.'));
    const max = parseFloat(m[2].replace(',', '.'));
    return { min, max };
  };

  const parseValue = (raw?: string | number | null) => {
    if (raw == null) return { op: null, value: null };
    const s = String(raw).trim();
    const m = s.match(/^([<>]=?)?\s*([0-9]+(?:[.,][0-9]+)?)$/);
    if (m) {
      const op = (m[1] || null) as string | null;
      const num = parseFloat(m[2].replace(',', '.'));
      return { op, value: isNaN(num) ? null : num };
    }
    const n = parseFloat(String(s).replace(',', '.'));
    return { op: null, value: isNaN(n) ? null : n };
  };

  const outStatus = (valor: any, rango: any): 'alto' | 'bajo' | null => {
    const v = parseValue(valor);
    const r = parseRange(rango);
    if (!r || v.value === null) return null;
    if (v.op === '<') return 'bajo';
    if (v.op === '>') return 'alto';
    if (v.value < r.min) return 'bajo';
    if (v.value > r.max) return 'alto';
    return null;
  };
  
  // Analiza los datos cuando llegan del servidor
  useEffect(() => {
    if (serverData?.documentos) {
      const nuevosHallazgos: Hallazgo[] = [];
      serverData.documentos.forEach(doc => {
        if (Array.isArray(doc.resultados)) {
          doc.resultados.forEach(res => {
            const estado = outStatus(res.valor, res.rango);
            if (estado) {
              nuevosHallazgos.push({ ...res, estado, archivo: doc.archivo });
            }
          });
        }
      });
      setHallazgos(nuevosHallazgos);
    }
  }, [serverData]);


  const onFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadedFiles(Array.from(e.target.files || []));
    setErrorMsg(null);
    setServerData(null);
    setHallazgos([]);
  };

  const onUpload = async () => {
    if (uploadedFiles.length === 0) return;

    setIsLoading(true);
    setErrorMsg(null);
    setServerData(null);
    setHallazgos([]);

    const baseApiUrl = import.meta.env.VITE_API_URL || 'http://localhost:4000';
    
    const uploadPromises = uploadedFiles.map(file => {
      const formData = new FormData();
      formData.append('file', file);
      if (pacienteId) formData.append('paciente_id', pacienteId);

      return fetch(`${baseApiUrl}/api/labs/upload`, {
        method: 'POST',
        body: formData,
      }).then(async res => {
          const payload = await res.json();
          if (!res.ok) throw payload;
          return payload;
      });
    });

    try {
      const allResponses = await Promise.all(uploadPromises);
      const aggregatedData: ServerResponse = { documentos: [], resumen_hallazgos: null };
      allResponses.forEach(payload => {
        aggregatedData.documentos.push(...(payload.documentos || []));
        if (payload.resumen_hallazgos && !aggregatedData.resumen_hallazgos) {
            aggregatedData.resumen_hallazgos = payload.resumen_hallazgos;
        }
      });
      setServerData(aggregatedData);
      setUploadedFiles([]);
    } catch (err: any) {
        setErrorMsg(err?.error || 'Error al procesar los archivos.');
    } finally {
      setIsLoading(false);
    }
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };
  
  const documentos = serverData?.documentos ?? [];
  const outOfRange = (valor: any, rango: any) => !!outStatus(valor, rango); // Helper para el renderizado

  return (
    <div className="space-y-6">
      <fieldset disabled={isLoading} className="space-y-6">

        {errorMsg && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-4">
            <div className="flex items-center gap-2 text-red-800 text-sm">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          </div>
        )}
        
        {serverData?.resumen_hallazgos && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4">
            <div className="flex items-center gap-2 text-emerald-800 text-sm">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
              <span>{serverData.resumen_hallazgos}</span>
            </div>
          </div>
        )}

        {hallazgos.length > 0 && (
          <section className="space-y-4">
            <h4 className="text-lg font-semibold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-200">
              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
              Hallazgos Relevantes
            </h4>
            <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-sm">
              <table className="min-w-full text-sm bg-white">
                <thead className="bg-slate-50">
                  <tr className="text-left">
                    <th className="py-3 px-4 font-medium text-slate-700">Prueba</th>
                    <th className="py-3 px-4 font-medium text-slate-700">Valor</th>
                    <th className="py-3 px-4 font-medium text-slate-700">Rango</th>
                    <th className="py-3 px-4 font-medium text-slate-700">Estado</th>
                  </tr>
                </thead>
                <tbody>
                  {hallazgos.map((b, idx) => (
                    <tr key={idx} className="border-t border-slate-100">
                      <td className="py-3 px-4 text-slate-800">{b.prueba}</td>
                      <td className="py-3 px-4 text-slate-800">{b.valor} {b.unidad ?? ''}</td>
                      <td className="py-3 px-4 text-slate-600">{b.rango}</td>
                      <td className="py-3 px-4 font-semibold">
                        {b.estado === 'alto' ? <span className="text-red-600">↑ Alto</span> : <span className="text-orange-600">↓ Bajo</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}

        <section className="space-y-4">
          <h4 className="text-lg font-semibold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-200">
            <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
            Cargar Resultados
          </h4>
          <div className="border-2 border-dashed border-slate-300 rounded-2xl p-12 flex flex-col items-center bg-slate-50">
            <Upload className="w-16 h-16 text-slate-400 mb-4" />
            <h4 className="text-lg font-semibold text-slate-900">Subir resultados</h4>
            <p className="text-slate-600 mb-6 mt-1">Arrastra o selecciona tus PDF/PNG/JPG.</p>
            <button
              onClick={() => document.getElementById('file-upload-input')?.click()}
              className="inline-flex items-center gap-2 rounded-xl border border-sky-200 bg-sky-600 px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Seleccionar Archivos
            </button>
            <input id="file-upload-input" type="file" multiple accept=".pdf,image/*" className="hidden" onChange={onFileSelect}/>
          </div>
        </section>

        {uploadedFiles.length > 0 && (
          <section className="space-y-4">
            <h4 className="text-lg font-semibold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-200">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              Archivos Seleccionados
            </h4>
            <ul className="space-y-3">
              {uploadedFiles.map((file, index) => (
                <li key={index} className="flex items-center gap-3 p-4 bg-white rounded-xl border border-slate-200 shadow-sm">
                  <FileText className="w-5 h-5 text-indigo-600 flex-shrink-0" />
                  <span className="text-sm text-slate-800 truncate flex-1" title={file.name}>
                    {file.name}
                  </span>
                  <span className="text-xs text-slate-500 px-2 py-1 bg-slate-100 rounded-full">
                    {Math.round(file.size / 1024)} KB
                  </span>
                  <button
                    onClick={() => removeFile(index)}
                    className="text-red-500 hover:text-red-700 text-lg font-bold w-6 h-6 flex items-center justify-center rounded-full hover:bg-red-100 transition-colors"
                    title="Eliminar archivo"
                  >
                    ×
                  </button>
                </li>
              ))}
            </ul>
            <div className="flex justify-center pt-4">
              <button
                onClick={onUpload}
                disabled={isLoading || uploadedFiles.length === 0}
                className="inline-flex items-center gap-2 rounded-xl border border-sky-200 bg-sky-600 px-6 py-3 text-sm font-medium text-white shadow-sm hover:bg-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Upload className="w-4 h-4" />
                {isLoading ? 'Procesando...' : `Analizar ${uploadedFiles.length} Archivo(s)`}
              </button>
            </div>
          </section>
        )}
        
        {documentos.length > 0 && (
          <section className="space-y-4">
            <h4 className="text-lg font-semibold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-200">
              <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
              Resultados Extraídos
            </h4>
            <div className="space-y-6">
              {documentos.map((doc, i) => (
                <div key={i} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                   <div className="flex flex-wrap items-center gap-3 mb-4">
                    <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-700 ring-1 ring-indigo-200">
                      <FileText className="w-3 h-3 mr-1" />
                      {doc.archivo || 'Archivo sin nombre'}
                    </span>
                    <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 ring-1 ring-slate-200">
                      Fecha: {doc.fecha_informe || 'No especificada'}
                    </span>
                   </div>
                  {Array.isArray(doc.resultados) && doc.resultados.length > 0 ? (
                    <div className="overflow-x-auto rounded-xl border border-slate-200">
                      <table className="min-w-full text-sm bg-white">
                        <thead className="bg-slate-50">
                          <tr className="text-left">
                            <th className="py-3 px-4 font-medium text-slate-700">Prueba</th>
                            <th className="py-3 px-4 font-medium text-slate-700">Valor</th>
                            <th className="py-3 px-4 font-medium text-slate-700">Unidad</th>
                            <th className="py-3 px-4 font-medium text-slate-700">Rango</th>
                          </tr>
                        </thead>
                        <tbody>
                          {doc.resultados.map((r, idx) => {
                            const estado = outStatus(r.valor, r.rango);
                            return (
                              <tr key={idx} className={cx("border-t border-slate-100", estado && "bg-red-50/30")}>
                                <td className="py-3 px-4 text-slate-800">{r.prueba}</td>
                                <td className="py-3 px-4">
                                  <div className="flex items-center gap-2">
                                    <span className="text-slate-800">{r.valor}</span>
                                    {estado && (
                                      <span className={cx("px-2 py-1 rounded-full text-xs font-medium", estado === 'alto' ? "bg-red-100 text-red-700 ring-1 ring-red-200" : "bg-orange-100 text-orange-700 ring-1 ring-orange-200")}>
                                        {estado === 'alto' ? '↑ Alto' : '↓ Bajo'}
                                      </span>
                                    )}
                                  </div>
                                </td>
                                <td className="py-3 px-4 text-slate-600">{r.unidad}</td>
                                <td className="py-3 px-4 text-slate-600">{r.rango}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                     <p className="text-sm text-slate-500 mt-4 p-4 bg-slate-50 rounded-lg">No se encontraron resultados tabulares en este documento.</p>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}
      </fieldset>
    </div>
  );
};

export default LaboratorioForm;